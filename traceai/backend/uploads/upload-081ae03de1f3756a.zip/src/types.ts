export type InputModality = 'text' | 'voice' | 'photo' | 'location';

export type PublicLifeIntent =
  | 'INFORMATION'
  | 'TRANSPORT'
  | 'MOBILITY'
  | 'COMMUNITY'
  | 'ENVIRONMENT'
  | 'ACCESSIBILITY'
  | 'SAFETY'
  | 'REPORT_ISSUE'
  | 'DAILY_PLANNING'
  | 'CREATIVE_SOLUTION';

export type PublicLifeDomain =
  | 'SMART_SOLUTIONS'
  | 'TRANSPORT_MOBILITY'
  | 'COMMUNITY_SERVICES'
  | 'ESSENTIAL_INFORMATION'
  | 'ENVIRONMENT_SUSTAINABILITY'
  | 'CREATIVE_DAILY_SOLUTIONS';

export type ResponseMode =
  | 'INFORM'
  | 'RECOMMEND'
  | 'PLAN'
  | 'COMPARE'
  | 'WARN'
  | 'GUIDE'
  | 'DRAFT'
  | 'ESCALATE';

export interface LocationContext {
  lat: number;
  lng: number;
  latitude?: number;
  longitude?: number;
  address: string;
  neighborhood?: string;
  district?: string;
  zoneType?: string;
  nearbyTransitHub?: string;
  placeName?: string;
  isSimulated?: boolean;
}

export interface NormalizedInput {
  id: string;
  userInput: string;
  modality: InputModality;
  location?: LocationContext;
  timestamp: string;
  intent: PublicLifeIntent;
  domain: PublicLifeDomain[];
  entities: Record<string, any>;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  accessibilityContext?: string;
  photoUrl?: string;
  photoBase64?: string;
}

export interface RecommendationOption {
  id: string;
  title: string;
  description: string;
  duration?: string;
  accessibilityGrade: 'Fully Accessible' | 'Assisted Only' | 'Step-free' | 'Standard';
  complexity: 'Low' | 'Moderate' | 'High';
  confidence: number;
  tradeoffs?: string;
  carbonImpact?: 'Ultra Low' | 'Low' | 'Moderate' | 'High';
  tags?: string[];
  actionLabel?: string;
  actionPayload?: any;
}

export interface RouteOption {
  id: string;
  name: string;
  mode: 'bus' | 'walk' | 'metro' | 'accessible-shuttle' | 'bike';
  durationMinutes: number;
  distanceKm: number;
  accessibilityGrade: 'Step-Free / Ramp Verified' | 'Assisted Incline' | 'Standard Walkway';
  inclineWarning?: string;
  crowdLevel: 'Low' | 'Moderate' | 'Heavy' | 'Overcrowded';
  confidence: number;
  stops: string[];
  waypoints: [number, number][];
  isRecommended?: boolean;
}

export interface CivicReportDraft {
  id: string;
  title: string;
  category:
    | 'POTHOLE'
    | 'WASTE'
    | 'BLOCKED_RAMP'
    | 'DAMAGED_INFRASTRUCTURE'
    | 'SIGNAGE'
    | 'TRAFFIC'
    | 'PUBLIC_SPACE'
    | 'ENVIRONMENT'
    | 'OTHER';
  description: string;
  location: string;
  coordinates?: { lat: number; lng: number };
  evidence: string;
  confidence: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
  suggestedAction: string;
  status: 'draft' | 'reviewed' | 'approved' | 'submitted';
  submissionNotice?: string;
  imageUri?: string;
  photoUrl?: string;
  timestamp: string;
  createdAt?: string;
  epistemicStatus: 'Detected' | 'Likely' | 'Needs verification';
}

export interface CreativeSolutionItem {
  id: string;
  title: string;
  category: 'PRACTICAL' | 'LOW-COST' | 'CREATIVE' | 'COMMUNITY-BASED' | 'SUSTAINABLE';
  description: string;
  feasibility: 'High' | 'Medium' | 'Experimental';
  cost: 'Free / Zero' | 'Minimal ($)' | 'Moderate ($$)';
  effort: '5 mins' | 'Same-day' | 'Community initiative';
  impactScore: number; // 0-100
}

export interface KnowledgeSource {
  name: string;
  verified: boolean;
  lastUpdated: string;
  relevance: number;
  excerpt?: string;
  url?: string;
}

export interface PipelineExecutionLog {
  stage:
    | 'SEE'
    | 'UNDERSTAND'
    | 'CONTEXTUALIZE'
    | 'REASON'
    | 'RECOMMEND'
    | 'VERIFY'
    | 'USER_APPROVAL'
    | 'ACT';
  label: string;
  detail: string;
  timestamp: string;
  status: 'pending' | 'running' | 'completed' | 'skipped';
  toolUsed?: string;
}

export interface CivicPulseResponse {
  id: string;
  situation: string;
  domains: PublicLifeDomain[];
  urgency: 'low' | 'medium' | 'high' | 'critical';
  mode: ResponseMode;
  whatIUnderstand: string;
  verifiedFacts: string[];
  inferences: string[];
  recommendations: RecommendationOption[];
  alternatives: string[];
  confidence: number;
  requiresApproval: boolean;
  nextStep: string;
  suggestedActions: {
    label: string;
    actionKey: string;
    iconName?: string;
    primary?: boolean;
    description?: string;
  }[];
  sources?: KnowledgeSource[];
  draftReport?: CivicReportDraft;
  routes?: RouteOption[];
  creativeSolutions?: CreativeSolutionItem[];
  explanationWhy: string;
  pipelineStages: PipelineExecutionLog[];
  isDemoData?: boolean;
}

export interface CivicServiceItem {
  id: string;
  name: string;
  category: 'Library' | 'Community Center' | 'Health Clinic' | 'Civic Office' | 'Waste / Recycling' | 'Public Park' | string;
  distance: string;
  address: string;
  hours: string;
  operatingHours?: string;
  description?: string;
  accessibilityRating?: string;
  contactPhone?: string;
  verified: boolean;
  relevanceScore: number;
  wheelchairAccessible: boolean;
  contact?: string;
  nextAction: string;
  requirements?: string[];
  coordinates: { lat: number; lng: number };
}

export interface UserMemory {
  id: string;
  text: string;
  category: 'mobility' | 'travel' | 'routine' | 'accessibility' | 'sustainability';
  createdAt: string;
}

export interface UserMemoryItem {
  id: string;
  category: 'accessibility' | 'transport' | 'environment' | 'location' | 'general';
  key: string;
  value: string;
  enabled: boolean;
  lastUpdated: string;
}

export interface ActivityItem {
  id: string;
  type: 'reasoning' | 'report' | 'recommendation' | 'route' | 'voice';
  title: string;
  description: string;
  timestamp: string;
  domain: string;
  status: 'completed' | 'pending' | 'draft';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'Citizen' | 'Municipal Advocate' | 'Transit Volunteer' | 'Guest';
  verifiedCitizen: boolean;
  district?: string;
  citizenBadgeId?: string;
}

export interface LateralSolution {
  id: string;
  title: string;
  category: 'PRACTICAL' | 'LOW-COST' | 'CREATIVE' | 'COMMUNITY_BASED' | 'SUSTAINABLE';
  description: string;
  feasibility: 'high' | 'medium' | 'experimental';
  cost: 'free' | 'low' | 'medium' | 'high';
  effort: 'low' | 'medium' | 'high';
  communityImpact: 'high' | 'medium' | 'low';
  upvotes: number;
}

export interface UserPreferences {
  mobilityPreference: 'standard' | 'wheelchair' | 'stroller' | 'step_free_only' | 'reduced_walking';
  travelPreference: 'balanced' | 'fastest' | 'eco_friendly' | 'sheltered';
  sustainabilityPriority: boolean;
  language: string;
  highContrast: boolean;
  voiceAutoRead: boolean;
  notificationsEnabled: boolean;
}

export interface CityIntelligencePattern {
  id: string;
  title: string;
  metricType: 'mobility_friction' | 'accessibility_hotspot' | 'waste_cluster' | 'community_demand' | 'information_gap';
  severity: 'low' | 'moderate' | 'elevated';
  locationName: string;
  trend: string;
  anonymizedSignalCount: number;
  insight: string;
  planningAction: string;
}

export interface PhotoAnalysisResult {
  detectedCategory:
    | 'POTHOLE'
    | 'WASTE'
    | 'BLOCKED_RAMP'
    | 'DAMAGED_INFRASTRUCTURE'
    | 'SIGNAGE'
    | 'TRAFFIC'
    | 'PUBLIC_SPACE'
    | 'ENVIRONMENT'
    | 'OTHER';
  confidence: number;
  visibleEvidence: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  relevantDomain: PublicLifeDomain;
  epistemicStatus: 'Detected' | 'Likely' | 'Needs verification';
  suggestedNextActions: string[];
  suggestedReportTitle: string;
  suggestedDescription: string;
}
