import { KnowledgeSource, CivicServiceItem, CityIntelligencePattern } from '../types';

export const VERIFIED_KNOWLEDGE_SOURCES: KnowledgeSource[] = [
  {
    name: 'Municipal Transit Authority — Accessible Transit Guidelines v4.2',
    verified: true,
    lastUpdated: '2026-08-15',
    relevance: 0.98,
    excerpt: 'All Line 14 and Rapid Bus vehicles operate automated low-floor ramps. By city ordinance §14-B, ramp boarding corridors must maintain a 36-inch (91cm) clear radius from curb obstruction.',
  },
  {
    name: 'Department of Public Works — Priority 1 Urban Accessibility Code',
    verified: true,
    lastUpdated: '2026-07-20',
    relevance: 0.94,
    excerpt: 'Reported ramp blockages and tactile paving hazards at high-volume transit nodes are classified as Priority 1-A dispatch incidents with targeted 90-minute field response times.',
  },
  {
    name: 'Metropolitan Community Directory — Verified Municipal Services',
    verified: true,
    lastUpdated: '2026-08-28',
    relevance: 0.91,
    excerpt: 'Civic Center Branch Library offers free public assistive technology stations, public meeting rooms, and notary services Monday–Saturday 9:00 AM to 7:00 PM.',
  },
  {
    name: 'City Environmental Services — Zero Waste & Clean Neighborhoods Protocol',
    verified: true,
    lastUpdated: '2026-08-01',
    relevance: 0.89,
    excerpt: 'Overflowing commercial or public park waste bins may be logged via 311 or municipal automated intake. Composting collection occurs on alternating Wednesdays.',
  }
];

export const DEMO_CIVIC_SERVICES: CivicServiceItem[] = [
  {
    id: 'srv-1',
    name: 'Civic Center Public Library & Tech Hub',
    category: 'Library',
    distance: '0.3 miles',
    address: '100 Larkin Street, Civic Center Plaza',
    hours: 'Open today: 9:00 AM – 7:00 PM',
    verified: true,
    relevanceScore: 96,
    wheelchairAccessible: true,
    contact: '(415) 557-4400',
    nextAction: 'View accessibility entrance on Fulton St',
    requirements: ['Government Photo ID for computer cards', 'No fee for public entrance'],
    coordinates: { lat: 37.7793, lng: -122.4175 }
  },
  {
    id: 'srv-2',
    name: 'Mission District Community Health & Care Clinic',
    category: 'Health Clinic',
    distance: '0.8 miles',
    address: '240 Shotwell Street',
    hours: 'Open today: 8:30 AM – 5:00 PM',
    verified: true,
    relevanceScore: 92,
    wheelchairAccessible: true,
    contact: '(415) 558-7000',
    nextAction: 'Check walk-in intake wait time',
    requirements: ['Proof of address', 'Insurance card or sliding-scale eligibility'],
    coordinates: { lat: 37.7635, lng: -122.4168 }
  },
  {
    id: 'srv-3',
    name: 'Downtown Municipal Services & Records Center',
    category: 'Civic Office',
    distance: '0.5 miles',
    address: '1 Dr Carlton B Goodlett Pl, Room 168',
    hours: 'Open today: 8:00 AM – 4:30 PM',
    verified: true,
    relevanceScore: 95,
    wheelchairAccessible: true,
    contact: '(415) 554-4000',
    nextAction: 'Reserve online appointment queue',
    requirements: ['Original birth certificate or passport', 'Proof of residency within last 60 days'],
    coordinates: { lat: 37.7792, lng: -122.4191 }
  },
  {
    id: 'srv-4',
    name: 'Green Canopy Community Garden & Tool Share',
    category: 'Community Center',
    distance: '0.6 miles',
    address: '550 Golden Gate Ave',
    hours: 'Open today: 10:00 AM – 6:00 PM',
    verified: true,
    relevanceScore: 88,
    wheelchairAccessible: true,
    contact: '(415) 556-9100',
    nextAction: 'Borrow public repair tools or attend workshop',
    requirements: ['Free community registration'],
    coordinates: { lat: 37.7812, lng: -122.4208 }
  },
  {
    id: 'srv-5',
    name: 'SoMa Eco-Drop Circular Recycling Depot',
    category: 'Waste / Recycling',
    distance: '1.1 miles',
    address: '780 Folsom Street',
    hours: 'Open today: 7:00 AM – 4:00 PM',
    verified: true,
    relevanceScore: 85,
    wheelchairAccessible: true,
    contact: '(415) 355-3700',
    nextAction: 'Check e-waste and textile drop-off limits',
    requirements: ['City resident verification for bulk items'],
    coordinates: { lat: 37.7828, lng: -122.4025 }
  }
];

export const DEMO_CITY_PATTERNS: CityIntelligencePattern[] = [
  {
    id: 'pat-1',
    title: 'Transit Corridor Accessibility Bottleneck',
    metricType: 'accessibility_hotspot',
    severity: 'elevated',
    locationName: 'Market & 4th Corridor',
    trend: '+24% reports this month',
    anonymizedSignalCount: 89,
    insight: 'Commercial loading during morning peak hours consistently blocks designated kneeling ramp access pads for bus lines 9, 14, and 38.',
    planningAction: 'Propose dynamic delivery bay geofencing & real-time sensor curb monitoring to the Transit Board.'
  },
  {
    id: 'pat-2',
    title: 'Peak Commuter Overcrowding Friction',
    metricType: 'mobility_friction',
    severity: 'moderate',
    locationName: 'Mission & 16th BART / Bus Intermodal Node',
    trend: 'Peak cluster: 7:45 AM – 8:45 AM',
    anonymizedSignalCount: 142,
    insight: 'Escalator maintenance coincides with surge in riders with mobility devices, increasing average transfer delays by 14 minutes.',
    planningAction: 'Schedule redundant surface electric shuttle connector during subway escalator overhaul windows.'
  },
  {
    id: 'pat-3',
    title: 'Weekend Park Perimeter Waste Influx',
    metricType: 'waste_cluster',
    severity: 'moderate',
    locationName: 'Dolores Park South Perimeter',
    trend: '+38% weekend volume over receptacle capacity',
    anonymizedSignalCount: 63,
    insight: 'Public bins reach 100% fill rate by 3:00 PM on sunny weekends, leading to overflow within 10 meters of pedestrian seating.',
    planningAction: 'Deploy solar compacting smart-bins with automatic dispatch telemetry to park maintenance crews.'
  },
  {
    id: 'pat-4',
    title: 'Civic Permit & Identification Documentation Gap',
    metricType: 'information_gap',
    severity: 'low',
    locationName: 'Central Municipal Records Center',
    trend: '31% of walk-in visitors arrive with incomplete utility documentation',
    anonymizedSignalCount: 110,
    insight: 'Citizens commonly misunderstand residency documentation rules before arriving in person.',
    planningAction: 'Implement proactive SMS pre-arrival checklist validation via CivicPulse AI.'
  }
];
