import { CivicPulseResponse, RouteOption, CivicReportDraft, CreativeSolutionItem } from '../types';

export interface DemoScenario {
  id: string;
  title: string;
  subtitle: string;
  query: string;
  modality: 'text' | 'voice' | 'photo' | 'location';
  locationName: string;
  photoUrl?: string;
  photoBase64Sample?: string;
  domain: string;
  sampleResponse: CivicPulseResponse;
}

export const PROMPTATHON_DEMO_SCENARIO: DemoScenario = {
  id: 'promptathon-main',
  title: 'Promptathon Grand Showcase: Overcrowded Stop & Blocked Ramp',
  subtitle: 'Live 7-Layer Pipeline: See → Understand → Contextualize → Reason → Recommend → Verify → Human Approval → Act',
  query: 'The bus stop near me is overcrowded, the accessibility ramp is blocked, and I need an accessible route.',
  modality: 'voice',
  locationName: '4th & Market St Transit Island (Stop #1492)',
  domain: 'Transport + Accessibility',
  sampleResponse: {
    id: 'res-promptathon-01',
    situation: 'Overcrowded Transit Node with Blocked Accessibility Ramp & Step-Free Route Urgency',
    domains: ['TRANSPORT_MOBILITY', 'SMART_SOLUTIONS'],
    urgency: 'high',
    mode: 'RECOMMEND',
    whatIUnderstand: 'You are currently at the 4th & Market transit stop. The boarding area is overcrowded, the physical wheelchair ramp is obstructed by commercial deliveries, and you urgently require a step-free, accessible connection without stairs or steep inclines.',
    verifiedFacts: [
      'Stop #1492 (4th & Market) has an active curb clearance regulation (§14-B).',
      'Next scheduled inbound Rapid Bus is 4 minutes away, but boarding is compromised due to the ramp blockage.',
      'Surface low-floor electric shuttle Stop #1510 is 180 meters east on Mission & 4th, with 100% verified step-free boarding.'
    ],
    inferences: [
      'Physical obstruction is likely a delivery pallet or utility cart based on citizen reporting trends.',
      'Boarding at current stop carries high risk of boarding refusal or physical hazard for wheelchair/stroller users.',
      'Walking 2.5 minutes to Mission & 4th saves approximately 11 minutes of waiting time and provides verified zero-step boarding.'
    ],
    recommendations: [
      {
        id: 'rec-1',
        title: 'Option A: Step-Free Route via Mission & 4th Shuttle (Recommended)',
        description: 'Take the gentle level sidewalk via Stevenson Alley to the Mission & 4th Accessible Stop. Shuttle #14X arrives in 5 mins with reserved wheelchair bay.',
        duration: '7 mins total',
        accessibilityGrade: 'Fully Accessible',
        complexity: 'Low',
        confidence: 94,
        tradeoffs: 'Requires 180m flat sidewalk roll/walk, completely bypasses the blocked crowd.',
        carbonImpact: 'Ultra Low',
        tags: ['Zero-Step', 'Low Crowd', 'Real-Time Tracked']
      },
      {
        id: 'rec-2',
        title: 'Option B: Underground Light Rail with Active Elevators (Powell Station)',
        description: 'Enter Powell St Station via the North Hall Street elevator (verified operational 8 mins ago). Take M-Ocean View inbound.',
        duration: '9 mins total',
        accessibilityGrade: 'Step-free',
        complexity: 'Moderate',
        confidence: 88,
        tradeoffs: 'Elevator required; slightly higher indoor ambient noise.',
        carbonImpact: 'Low',
        tags: ['Sheltered', 'Weather-proof']
      },
      {
        id: 'rec-3',
        title: 'Option C: On-Demand Paratransit / City Micro-Shuttle Dispatch',
        description: 'Request priority curb pickup at designated yellow zone 50m south on 4th Street.',
        duration: '14 mins wait',
        accessibilityGrade: 'Fully Accessible',
        complexity: 'Low',
        confidence: 82,
        tradeoffs: 'Longer wait time, door-to-door direct service.',
        carbonImpact: 'Moderate',
        tags: ['Direct Door-to-Door', 'Assisted']
      }
    ],
    alternatives: [
      'Wait for the next surface bus (Line 38) at the current stop if maintenance clears the ramp within 10 minutes.',
      'Request transit ambassador assistance via the emergency callbox located 15ft behind shelter.'
    ],
    confidence: 91,
    requiresApproval: true,
    nextStep: 'Choose your preferred accessible route, then review the automated Civic Report draft to dispatch city ramp clearance.',
    suggestedActions: [
      {
        label: 'View Accessible Route on Map',
        actionKey: 'VIEW_ROUTE',
        iconName: 'MapPin',
        primary: true,
        description: 'Inspect step-free turn-by-turn guidance to Mission & 4th.'
      },
      {
        label: 'Review & Dispatch Ramp Clearance Draft',
        actionKey: 'PREPARE_REPORT',
        iconName: 'FileText',
        primary: false,
        description: 'Inspect pre-filled Priority 1-A report for transit maintenance.'
      },
      {
        label: 'Explore Creative Alternatives',
        actionKey: 'CREATIVE_SOLUTIONS',
        iconName: 'Sparkles',
        primary: false,
        description: 'See innovative, community-based or low-cost adjustments.'
      }
    ],
    sources: [
      {
        name: 'Municipal Transit API (Simulated Demo Stream)',
        verified: true,
        lastUpdated: '2 minutes ago',
        relevance: 0.96
      },
      {
        name: 'City Accessibility Infrastructure Database',
        verified: true,
        lastUpdated: 'Today at 08:00 AM',
        relevance: 0.94
      }
    ],
    draftReport: {
      id: 'rep-draft-001',
      title: 'Urgent Accessibility Ramp Obstruction at 4th & Market Bus Stop #1492',
      category: 'BLOCKED_RAMP',
      description: 'The primary wheelchair kneeling ramp and tactile guide path at Bus Stop #1492 (4th & Market) is blocked by commercial loading cargo and crowd spillover. Passengers with mobility devices and strollers cannot safely board oncoming Line 14 and 38 buses.',
      location: 'Stop #1492, Southbound Market at 4th St, San Francisco, CA',
      coordinates: { lat: 37.7858, lng: -122.4065 },
      evidence: 'Observed cargo pallet directly obstructing designated 36-inch curb-cut ramp pad. High pedestrian congestion causing safety hazard.',
      confidence: 89,
      priority: 'high',
      suggestedAction: 'Dispatch transit field officer or parking enforcement to clear curb corridor immediately and notify oncoming bus drivers.',
      status: 'draft',
      epistemicStatus: 'Detected',
      timestamp: 'Just now'
    },
    routes: [
      {
        id: 'rt-1',
        name: 'Route A — Flat Sidewalk Connector to Mission & 4th (Step-Free)',
        mode: 'walk',
        durationMinutes: 4,
        distanceKm: 0.22,
        accessibilityGrade: 'Step-Free / Ramp Verified',
        crowdLevel: 'Low',
        confidence: 96,
        stops: ['Current: 4th & Market Obstruction', 'Stevenson Level Way', 'Mission & 4th Accessible Stop #1510'],
        waypoints: [
          [37.7858, -122.4065],
          [37.7852, -122.4055],
          [37.7845, -122.4042]
        ],
        isRecommended: true
      },
      {
        id: 'rt-2',
        name: 'Route B — Powell Metro Station (Elevator Verified)',
        mode: 'metro',
        durationMinutes: 8,
        distanceKm: 0.35,
        accessibilityGrade: 'Step-Free / Ramp Verified',
        crowdLevel: 'Moderate',
        confidence: 89,
        stops: ['Powell North Elevator', 'Mezzanine Concourse', 'Platform Inbound'],
        waypoints: [
          [37.7858, -122.4065],
          [37.7844, -122.4079],
          [37.7838, -122.4085]
        ]
      }
    ],
    creativeSolutions: [
      {
        id: 'cs-1',
        title: 'Transit Ambassador Signal Chime',
        category: 'PRACTICAL',
        description: 'Press the blue accessibility callbox button on the transit shelter column. This activates driver dashboard alerts on approaching buses to deploy rear kneeling doors.',
        feasibility: 'High',
        cost: 'Free / Zero',
        effort: '5 mins',
        impactScore: 92
      },
      {
        id: 'cs-2',
        title: 'Temporary Crowd Buffer Corridor',
        category: 'COMMUNITY-BASED',
        description: 'CivicPulse can notify nearby enrolled community mobility guides to guide pedestrians 3 feet back from the boarding yellow line.',
        feasibility: 'Medium',
        cost: 'Free / Zero',
        effort: 'Community initiative',
        impactScore: 84
      }
    ],
    explanationWhy: 'This recommendation prioritizes step-free physical safety, eliminates stair navigation, and routes around confirmed delivery curb blockages using verified sidewalk grades.',
    pipelineStages: [
      { stage: 'SEE', label: 'Input Signal Ingestion', detail: 'Received voice speech query + geolocation (4th & Market)', timestamp: '00:00.10', status: 'completed' },
      { stage: 'UNDERSTAND', label: 'Intent & Domain Extraction', detail: 'Identified dual intent: Transit routing + Physical accessibility hazard', timestamp: '00:00.25', status: 'completed' },
      { stage: 'CONTEXTUALIZE', label: 'Spatial & Transit Grounding', detail: 'Checked live stop crowd telemetry & sidewalk elevation maps', timestamp: '00:00.42', status: 'completed', toolUsed: 'getAccessibleRoutes + getLocationContext' },
      { stage: 'REASON', label: 'Tradeoff & Risk Modeling', detail: 'Determined waiting at current stop has 76% failure risk due to pallet blockage', timestamp: '00:00.60', status: 'completed' },
      { stage: 'RECOMMEND', label: 'Option Generation', detail: 'Synthesized 3 distinct paths with accessibility grading and confidence scores', timestamp: '00:00.75', status: 'completed' },
      { stage: 'VERIFY', label: 'Safety & Epistemic Check', detail: 'Separated verified sidewalk facts from estimated clearance times', timestamp: '00:00.90', status: 'completed' },
      { stage: 'USER_APPROVAL', label: 'Human-in-the-Loop Gate', detail: 'Awaiting user decision before dispatching civic report or navigation', timestamp: '00:01.05', status: 'completed' },
      { stage: 'ACT', label: 'Interactive Execution Ready', detail: 'Ready to display step-free map, preview report draft, or answer questions', timestamp: '00:01.12', status: 'completed' }
    ],
    isDemoData: true
  }
};

export const OTHER_DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'waste-overflow',
    title: 'Environmental Challenge: Overflowing Park Waste',
    subtitle: 'Environment & Sustainability Domain • Civic Report Drafting',
    query: 'There is waste overflowing near this park playground and plastic bottles are blowing into the flowerbeds.',
    modality: 'photo',
    locationName: 'Dolores Park Children’s Playground North Corner',
    domain: 'Environment & Sustainability',
    sampleResponse: {
      id: 'res-waste-02',
      situation: 'Overflowing Park Public Receptacle near Children’s Recreation Zone',
      domains: ['ENVIRONMENT_SUSTAINABILITY', 'COMMUNITY_SERVICES'],
      urgency: 'medium',
      mode: 'DRAFT',
      whatIUnderstand: 'Public trash bins at Dolores Park North Corner are overflowing onto the lawn, creating litter scatter near children’s play amenities and environmental hazards for local wildlife.',
      verifiedFacts: [
        'Park bins are serviced by Department of Recreation & Parks.',
        'Zero Waste Ordinance requires prompt remediation for recyclable plastic containment.'
      ],
      inferences: [
        'Overflow is likely due to sunny weekend picnic traffic exceeding 50-gallon capacity.',
        'Risk of debris scattering across adjacent residential storm drains is moderate if wind increases.'
      ],
      recommendations: [
        {
          id: 'rec-w-1',
          title: 'Option A: Log Municipal Park Service Ticket with Geo-Tag',
          description: 'Prepare a pre-filled 311 Priority Receptacle Emptying ticket with photo evidence.',
          duration: '3 mins to draft',
          accessibilityGrade: 'Standard',
          complexity: 'Low',
          confidence: 95,
          tradeoffs: 'Dispatches official parks truck within 2–4 hours.',
          carbonImpact: 'Ultra Low',
          tags: ['Official Intake', 'Photo Grounded']
        },
        {
          id: 'rec-w-2',
          title: 'Option B: Secondary Clean Receptacle Location (90m away)',
          description: 'Locate underutilized high-capacity solar compacting bins near the 19th & Dolores tennis courts.',
          duration: '2 mins walk',
          accessibilityGrade: 'Step-free',
          complexity: 'Low',
          confidence: 90,
          tradeoffs: 'Immediate clean disposal for present park-goers.',
          carbonImpact: 'Low',
          tags: ['Immediate Action', 'Solar Compactor']
        }
      ],
      alternatives: [
        'Organize a 10-minute neighborhood volunteer litter sweep using the community garden tool shed.'
      ],
      confidence: 93,
      requiresApproval: true,
      nextStep: 'Review the pre-filled park service ticket draft and confirm submission.',
      suggestedActions: [
        { label: 'Review Service Ticket Draft', actionKey: 'PREPARE_REPORT', iconName: 'FileText', primary: true },
        { label: 'Find Nearest Empty Bin on Map', actionKey: 'VIEW_ROUTE', iconName: 'MapPin', primary: false }
      ],
      draftReport: {
        id: 'rep-waste-002',
        title: 'Park Waste Receptacle Overflow near Children’s Playground',
        category: 'WASTE',
        description: 'Public waste bins at Dolores Park North Lawn adjacent to children’s play area are at 120% capacity with scattered plastic recyclables and food packaging.',
        location: 'Dolores Park North Corner, near 19th St entrance, San Francisco, CA',
        coordinates: { lat: 37.7596, lng: -122.4269 },
        evidence: 'Visual evidence of litter overflow spilling over 2 meters onto public grass.',
        confidence: 92,
        priority: 'medium',
        suggestedAction: 'Dispatch park sanitation crew for urgent bin clearance and litter sweep.',
        status: 'draft',
        epistemicStatus: 'Detected',
        timestamp: 'Just now'
      },
      explanationWhy: 'Generated ticket targeting park maintenance service standards while providing nearby alternative disposal options.',
      pipelineStages: [],
      isDemoData: true
    }
  },
  {
    id: 'service-checklist',
    title: 'Essential Information: Municipal Records & ID Checklist',
    subtitle: 'Essential Information Domain • Document Validation Guide',
    query: 'What do I need before visiting the public records office to renew my resident transit card?',
    modality: 'text',
    locationName: 'City Hall Municipal Services, Room 168',
    domain: 'Essential Information',
    sampleResponse: {
      id: 'res-info-03',
      situation: 'Citizen Document Preparation for Transit Access Card Renewal',
      domains: ['ESSENTIAL_INFORMATION', 'COMMUNITY_SERVICES'],
      urgency: 'low',
      mode: 'GUIDE',
      whatIUnderstand: 'You are preparing an in-person visit to City Hall Municipal Records Center to renew your municipal transit pass and need an accurate checklist to avoid repeat trips.',
      verifiedFacts: [
        'Office hours are Monday–Friday 8:00 AM to 4:30 PM (last appointment intake at 4:00 PM).',
        'Physical photo ID and primary proof of residential address are mandatory.',
        'Online digital appointments reduce typical wait time from 45 mins to under 10 mins.'
      ],
      inferences: [
        'Utility bill dates must be within 60 calendar days to be accepted without rejection.'
      ],
      recommendations: [
        {
          id: 'rec-i-1',
          title: 'Required Document Checklist',
          description: '1. Government Photo ID (Passport/Driver’s License). 2. Utility or Lease document dated within 60 days. 3. Current Transit Card ID number. 4. $15 fee or fee-waiver form.',
          duration: 'Verify before leaving',
          accessibilityGrade: 'Fully Accessible',
          complexity: 'Low',
          confidence: 97,
          tradeoffs: 'Ensures 100% single-trip success rate.',
          tags: ['Verified Requirements', 'No Repeat Trips']
        }
      ],
      alternatives: [
        'Renew online through the municipal transit portal if you have active digital state ID credentials.'
      ],
      confidence: 96,
      requiresApproval: false,
      nextStep: 'Check off your document list or reserve your entry appointment ticket.',
      suggestedActions: [
        { label: 'View Service Location & Hours', actionKey: 'VIEW_SERVICE', iconName: 'Clock', primary: true },
        { label: 'Check Transit Route to City Hall', actionKey: 'VIEW_ROUTE', iconName: 'Navigation', primary: false }
      ],
      explanationWhy: 'Derived directly from official Metropolitan Municipal Transit Authority verification guidelines.',
      pipelineStages: [],
      isDemoData: true
    }
  }
];

export const SAMPLE_SCENARIOS: DemoScenario[] = [
  PROMPTATHON_DEMO_SCENARIO,
  ...OTHER_DEMO_SCENARIOS,
];
