import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  CheckCircle2,
  AlertCircle,
  Eye,
  Cpu,
  Database,
  Send,
  ShieldCheck,
  MousePointerClick,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { PipelineExecutionLog } from '../types';

interface PipelineVisualizerProps {
  stages?: PipelineExecutionLog[];
  isProcessing?: boolean;
  activeStageIndex?: number;
}

export const PipelineVisualizer: React.FC<PipelineVisualizerProps> = ({
  stages = [],
  isProcessing = false,
  activeStageIndex,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const defaultLayers = [
    { key: 'SEE', name: '1. User Experience', desc: 'Text • Voice • Photo • Location', icon: Eye, color: 'text-cyan-400' },
    { key: 'UNDERSTAND', name: '2. Input Processing', desc: 'Intent, Entities & Vision Signal', icon: Layers, color: 'text-blue-400' },
    { key: 'CONTEXTUALIZE', name: '3. AI Orchestration', desc: 'Context Engine & Prompt Router', icon: Cpu, color: 'text-violet-400' },
    { key: 'REASON', name: '4. Models & Knowledge', desc: 'Gemini 3.8 Flash + Municipal KB', icon: Database, color: 'text-purple-400' },
    { key: 'RECOMMEND', name: '5. Response Engine', desc: 'Multi-Option A/B/C Synthesis', icon: Send, color: 'text-cyan-400' },
    { key: 'VERIFY', name: '6. Safety & Human Gate', desc: 'Epistemic Audit & Approval Check', icon: ShieldCheck, color: 'text-emerald-400' },
    { key: 'ACT', name: '7. User Action', desc: 'Route Map • Report Draft • Execution', icon: MousePointerClick, color: 'text-amber-400' },
  ];

  return (
    <div className="w-full rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-xl shadow-cyan-950/20 overflow-hidden transition-all">
      {/* Visualizer Header */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between px-4 py-3 bg-slate-950/60 hover:bg-slate-900/70 cursor-pointer border-b border-slate-800/70 transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-700/50 text-cyan-300">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                7-Layer AI Architecture Pipeline
              </span>
              {isProcessing && (
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 animate-pulse border border-cyan-500/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                  Processing Live Signals
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400">
              See → Understand → Contextualize → Reason → Recommend → Verify → User Approval → Act
            </p>
          </div>
        </div>

        <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-cyan-300 transition-colors">
          <span>{isExpanded ? 'Hide Architecture Flow' : 'Inspect Architecture'}</span>
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Pipeline Diagram Bar */}
      <div className="p-3 bg-slate-950/30 overflow-x-auto">
        <div className="flex items-center justify-between min-w-[700px] gap-2">
          {defaultLayers.map((layer, idx) => {
            const Icon = layer.icon;
            const logItem = stages.find((s) => s.stage === layer.key);
            const isFinished = logItem?.status === 'completed';
            const isActive = isProcessing && activeStageIndex === idx;

            return (
              <React.Fragment key={layer.key}>
                <div
                  className={`flex-1 flex flex-col items-center text-center p-2 rounded-xl border transition-all ${
                    isActive
                      ? 'bg-cyan-950/60 border-cyan-400/80 shadow-md shadow-cyan-950/50 scale-[1.03]'
                      : isFinished
                      ? 'bg-slate-900/90 border-slate-700/80'
                      : 'bg-slate-950/50 border-slate-800/60 opacity-80'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center mb-1.5 ${
                      isActive
                        ? 'bg-cyan-500 text-slate-950 animate-bounce'
                        : isFinished
                        ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-600/50'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {isFinished ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                  </div>
                  <span className="text-[11px] font-bold text-slate-200 leading-tight">
                    {layer.name}
                  </span>
                  <span className="text-[9px] text-slate-400 line-clamp-1 mt-0.5">
                    {layer.desc}
                  </span>
                </div>

                {idx < defaultLayers.length - 1 && (
                  <div className="text-slate-600 shrink-0 text-xs font-bold select-none">
                    →
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Expanded Logs & Tool Execution Details */}
      {isExpanded && (
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/80">
            <span className="font-semibold text-slate-300">Live Stage Telemetry & Audit Trail</span>
            <span>Total execution: {stages.length > 0 ? `${stages.length} stages registered` : 'Standby'}</span>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {stages.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-2 text-center">
                Submit a voice query, photo, or launch the Grand Demo to view real-time stage logging.
              </p>
            ) : (
              stages.map((stage, i) => (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800/70 text-xs"
                >
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                      {stage.stage}
                    </span>
                    <div>
                      <p className="font-medium text-slate-200">{stage.label}</p>
                      <p className="text-slate-400 text-[11px] mt-0.5">{stage.detail}</p>
                      {stage.toolUsed && (
                        <p className="text-[10px] text-violet-400 mt-1 flex items-center gap-1">
                          <Cpu className="w-3 h-3" />
                          <span>Tool Invocations: {stage.toolUsed}</span>
                        </p>
                      )}
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 shrink-0">
                    {stage.timestamp}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
