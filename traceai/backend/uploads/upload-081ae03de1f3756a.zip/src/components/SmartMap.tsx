import React, { useState } from 'react';
import {
  MapPin,
  Navigation,
  Layers,
  Info,
  ShieldCheck,
  AlertTriangle,
  Bus,
  Library,
  HeartPulse,
  Leaf,
  Compass,
  Sparkles,
} from 'lucide-react';
import { DEMO_CIVIC_SERVICES } from '../data/civicKnowledge';
import { RouteOption } from '../types';

interface SmartMapProps {
  activeRoute?: RouteOption;
  highlightCategory?: string;
  onSelectService?: (service: any) => void;
  onAskAboutPlace?: (placeName: string) => void;
}

type MapLayer = 'ALL' | 'TRANSPORT' | 'ACCESSIBILITY' | 'COMMUNITY' | 'ENVIRONMENT' | 'ISSUES';

export const SmartMap: React.FC<SmartMapProps> = ({
  activeRoute,
  onSelectService,
  onAskAboutPlace,
}) => {
  const [activeLayer, setActiveLayer] = useState<MapLayer>('ALL');
  const [selectedPin, setSelectedPin] = useState<any | null>(null);

  // Map markers for civic life
  const mapNodes = [
    {
      id: 'pin-1',
      title: 'Current Location: 4th & Market Stop #1492',
      category: 'ISSUES',
      type: 'issue',
      x: 320,
      y: 190,
      status: 'Blocked Ramp Obstruction',
      severity: 'high',
      details: 'Commercial cargo obstructing designated curb-cut ramp pad. Heavy crowd congestion.',
      stepFree: false,
    },
    {
      id: 'pin-2',
      title: 'Alternate Shuttle Stop #1510 (Mission & 4th)',
      category: 'ACCESSIBILITY',
      type: 'transit',
      x: 520,
      y: 290,
      status: '100% Step-Free Verified',
      severity: 'low',
      details: 'Gentle grade sidewalk corridor. Reserved wheelchair bay arriving in 5 mins.',
      stepFree: true,
    },
    {
      id: 'pin-3',
      title: 'Civic Center Public Library & Assistive Tech',
      category: 'COMMUNITY',
      type: 'service',
      x: 180,
      y: 140,
      status: 'Open today until 7:00 PM',
      severity: 'low',
      details: 'Full ramp access on Fulton St, screen-reader stations, notary services.',
      stepFree: true,
    },
    {
      id: 'pin-4',
      title: 'Powell Metro Station (North Elevator)',
      category: 'TRANSPORT',
      type: 'transit',
      x: 240,
      y: 220,
      status: 'Elevator Operational',
      severity: 'low',
      details: 'Inspected 8 mins ago. Underground direct connection.',
      stepFree: true,
    },
    {
      id: 'pin-5',
      title: 'SoMa Eco-Drop Circular Recycling Depot',
      category: 'ENVIRONMENT',
      type: 'environment',
      x: 580,
      y: 180,
      status: 'Open until 4:00 PM',
      severity: 'low',
      details: 'Textile drop-off, battery recycling, solar compacting station.',
      stepFree: true,
    },
    {
      id: 'pin-6',
      title: 'Dolores Park Children’s Playground Corner',
      category: 'ENVIRONMENT',
      type: 'issue',
      x: 120,
      y: 340,
      status: 'Waste Overflow Reported',
      severity: 'medium',
      details: 'Public bins at 120% capacity. Volunteer sweep requested.',
      stepFree: true,
    },
  ];

  const filteredNodes = mapNodes.filter((node) => {
    if (activeLayer === 'ALL') return true;
    return node.category === activeLayer;
  });

  return (
    <div className="w-full rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
      {/* Map Control Bar */}
      <div className="p-3.5 bg-slate-950/80 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Interactive Smart City Map
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80">
                DEMO MOBILITY DATA
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Live transit corridors, verified accessibility ramps, public hubs & reported civic issues.
            </p>
          </div>
        </div>

        {/* Layer Filters */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'ALL', label: 'All Layers' },
            { id: 'TRANSPORT', label: 'Transport' },
            { id: 'ACCESSIBILITY', label: 'Accessibility' },
            { id: 'COMMUNITY', label: 'Community' },
            { id: 'ENVIRONMENT', label: 'Environment' },
            { id: 'ISSUES', label: 'Issues' },
          ].map((layer) => (
            <button
              key={layer.id}
              onClick={() => setActiveLayer(layer.id as MapLayer)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all shrink-0 ${
                activeLayer === layer.id
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {layer.label}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Vector SVG Canvas */}
      <div className="relative w-full h-[360px] sm:h-[440px] bg-slate-950 overflow-hidden select-none">
        {/* Futuristic Map Grid Lines */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 700 440"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Subtle Grid */}
          <defs>
            <pattern id="city-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.8" strokeOpacity="0.4" />
            </pattern>
            <linearGradient id="route-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#3b82f6" />
            </linearGradient>
          </defs>

          <rect width="100%" height="100%" fill="#090d16" />
          <rect width="100%" height="100%" fill="url(#city-grid)" />

          {/* Major Urban Corridors */}
          {/* Market Street Diagonal */}
          <line x1="80" y1="360" x2="620" y2="90" stroke="#1e293b" strokeWidth="24" strokeLinecap="round" />
          <line x1="80" y1="360" x2="620" y2="90" stroke="#334155" strokeWidth="2" strokeDasharray="6 6" />

          {/* Mission Street */}
          <line x1="140" y1="420" x2="680" y2="150" stroke="#1e293b" strokeWidth="18" strokeLinecap="round" />

          {/* 4th Street Crossway */}
          <line x1="280" y1="60" x2="480" y2="400" stroke="#1e293b" strokeWidth="18" strokeLinecap="round" />

          {/* Stevenson Level Walkway (Accessible Bypass) */}
          <path
            d="M 320 190 Q 420 220 520 290"
            fill="none"
            stroke="url(#route-gradient)"
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray="8 4"
            className="animate-pulse"
          />

          {/* Street Name Labels */}
          <text x="440" y="160" fill="#64748b" fontSize="11" fontFamily="sans-serif" transform="rotate(-26, 440, 160)">
            MARKET STREET TRANSIT SPINE
          </text>
          <text x="360" y="340" fill="#64748b" fontSize="11" fontFamily="sans-serif" transform="rotate(-26, 360, 340)">
            MISSION STREET CORRIDOR
          </text>
          <text x="420" y="270" fill="#38bdf8" fontSize="10" fontFamily="sans-serif" fontWeight="bold">
            ◄ Step-Free Shuttle Bypass (7 mins)
          </text>

          {/* Map Nodes / Interactive Pins */}
          {filteredNodes.map((node) => {
            const isSelected = selectedPin?.id === node.id;
            let pinColor = '#38bdf8'; // cyan
            if (node.severity === 'high') pinColor = '#f43f5e'; // red
            if (node.severity === 'medium') pinColor = '#f59e0b'; // amber
            if (node.category === 'COMMUNITY') pinColor = '#a855f7'; // violet
            if (node.category === 'ENVIRONMENT') pinColor = '#10b981'; // green

            return (
              <g
                key={node.id}
                onClick={() => setSelectedPin(node)}
                className="cursor-pointer group"
                transform={`translate(${node.x}, ${node.y})`}
              >
                {/* Pulse Ring */}
                <circle
                  r={isSelected ? '22' : '14'}
                  fill={pinColor}
                  fillOpacity={isSelected ? '0.3' : '0.15'}
                  className="animate-ping"
                  style={{ animationDuration: '3s' }}
                />

                {/* Base Pin Circle */}
                <circle
                  r={isSelected ? '14' : '10'}
                  fill="#020617"
                  stroke={pinColor}
                  strokeWidth={isSelected ? '3' : '2'}
                  className="transition-all"
                />

                {/* Pin Center Dot */}
                <circle r="4" fill={pinColor} />

                {/* Label On Hover or Selected */}
                <text
                  x="0"
                  y="-18"
                  textAnchor="middle"
                  fill="#f8fafc"
                  fontSize="11"
                  fontWeight="bold"
                  className="pointer-events-none drop-shadow-md"
                >
                  {node.title.split(':')[0]}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Selected Marker Floating Overlay Card */}
        {selectedPin && (
          <div className="absolute bottom-3 left-3 right-3 sm:right-auto sm:max-w-sm rounded-2xl bg-slate-900/95 border border-cyan-700/80 p-4 shadow-2xl backdrop-blur-xl animate-fade-in text-slate-100 z-10 space-y-2.5">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
                  {selectedPin.category}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-white mt-1">
                  {selectedPin.title}
                </h4>
              </div>
              <button
                onClick={() => setSelectedPin(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {selectedPin.details}
            </p>

            <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800 text-slate-400">
              <span>Status: <strong className="text-cyan-300">{selectedPin.status}</strong></span>
              <span>{selectedPin.stepFree ? '✓ Step-Free' : '⚠️ Barrier'}</span>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  if (onAskAboutPlace) onAskAboutPlace(selectedPin.title);
                }}
                className="flex-1 py-1.5 px-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-semibold text-center transition-colors"
              >
                Ask CivicPulse About This
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Map Legend Footer */}
      <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between flex-wrap gap-2 text-[11px] text-slate-400">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            <span>Reported Barrier</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            <span>Step-Free Transit Hub</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span>Eco / Circular Depot</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-violet-400"></span>
            <span>Public Library / Clinic</span>
          </span>
        </div>
        <span className="text-[10px] text-slate-500 italic">
          Spatial telemetry rendered via simulated municipal GIS grid.
        </span>
      </div>
    </div>
  );
};
