import React, { useState } from 'react';
import {
  BrainCircuit,
  Plus,
  Trash2,
  ShieldCheck,
  CheckCircle2,
  Sliders,
  AlertCircle,
} from 'lucide-react';
import { UserMemoryItem } from '../types';

export const MemoryCenterView: React.FC = () => {
  const [memories, setMemories] = useState<UserMemoryItem[]>([
    {
      id: 'mem-1',
      category: 'accessibility',
      key: 'wheelchair_step_free',
      value: 'User requires 100% step-free accessible transit corridors and curb-cuts.',
      enabled: true,
      lastUpdated: '2025-02-10',
    },
    {
      id: 'mem-2',
      category: 'transport',
      key: 'transit_mode_priority',
      value: 'Prefers electrified light-rail and clean municipal buses over ride-hail.',
      enabled: true,
      lastUpdated: '2025-02-12',
    },
    {
      id: 'mem-3',
      category: 'environment',
      key: 'low_carbon_preference',
      value: 'Flag lowest carbon transit options and circular recycling drop locations.',
      enabled: true,
      lastUpdated: '2025-02-14',
    },
    {
      id: 'mem-4',
      category: 'location',
      key: 'frequent_corridor',
      value: 'Regular corridor: Market Street between 4th and Van Ness.',
      enabled: true,
      lastUpdated: '2025-02-16',
    },
  ]);

  const [newCategory, setNewCategory] = useState<'accessibility' | 'transport' | 'environment' | 'location' | 'general'>('accessibility');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');

  const handleToggle = (id: string) => {
    setMemories((prev) =>
      prev.map((m) => (m.id === id ? { ...m, enabled: !m.enabled } : m))
    );
  };

  const handleDelete = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all civic memory items?')) {
      setMemories([]);
    }
  };

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;

    const newMem: UserMemoryItem = {
      id: `mem-${Date.now()}`,
      category: newCategory,
      key: newKey.trim(),
      value: newValue.trim(),
      enabled: true,
      lastUpdated: new Date().toISOString().split('T')[0],
    };

    setMemories([...memories, newMem]);
    setNewKey('');
    setNewValue('');
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 border border-cyan-700/40 p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 shadow-md">
              <BrainCircuit className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">Citizen Memory & Personalization Center</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                  USER CONTROLLED
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Transparent personalization. You see, edit, toggle, and delete every memory item.
              </p>
            </div>
          </div>

          {memories.length > 0 && (
            <button
              onClick={handleClearAll}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-300 text-xs font-semibold transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Memory</span>
            </button>
          )}
        </div>
      </div>

      {/* Epistemic Privacy Principle */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300">
        <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          <strong>Zero Hidden Profiling:</strong> CivicPulse never uses opaque machine-learned shadow profiles. Every preference used to calibrate transit routes or service checklists is explicitly listed here.
        </span>
      </div>

      {/* Memory Items List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Active Preference & Memory Entries ({memories.length})
          </span>
          <span className="text-[11px] text-slate-500">
            Toggle switches to disable without deleting
          </span>
        </div>

        {memories.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-2">
            <p className="text-sm font-semibold text-slate-300">No active memory items</p>
            <p className="text-xs text-slate-500">CivicPulse will reason strictly with neutral default public baselines.</p>
          </div>
        ) : (
          memories.map((mem) => (
            <div
              key={mem.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                mem.enabled
                  ? 'bg-slate-900/90 border-slate-800'
                  : 'bg-slate-950/60 border-slate-900 opacity-60'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
                    {mem.category}
                  </span>
                  <span className="font-mono text-xs text-slate-400">{mem.key}</span>
                  <span className="text-[10px] text-slate-600">Updated: {mem.lastUpdated}</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-200">{mem.value}</p>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center">
                <button
                  onClick={() => handleToggle(mem.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    mem.enabled
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {mem.enabled ? 'Enabled' : 'Paused'}
                </button>

                <button
                  onClick={() => handleDelete(mem.id)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800 transition-colors"
                  title="Delete memory item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add New Memory Form */}
      <form
        onSubmit={handleAddMemory}
        className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl"
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
          <Plus className="w-4 h-4" />
          <span>Add Custom Citizen Preference</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Category:
            </label>
            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value as any)}
              className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200"
            >
              <option value="accessibility">Accessibility</option>
              <option value="transport">Transport</option>
              <option value="environment">Environment</option>
              <option value="location">Location</option>
              <option value="general">General</option>
            </select>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Preference Identifier / Key:
            </label>
            <input
              type="text"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              placeholder="e.g. avoid_stairs_only or stroller_friendly"
              className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-500 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">
            Exact Instruction for CivicPulse AI:
          </label>
          <input
            type="text"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            placeholder="e.g. Always prioritize sidewalk corridors with tactile pavers and shade."
            className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-500 outline-none"
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!newKey.trim() || !newValue.trim()}
            className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white text-xs font-semibold shadow-md shadow-cyan-950/50 transition-all"
          >
            Save Memory Instruction
          </button>
        </div>
      </form>
    </div>
  );
};
