import React from 'react';
import { Sparkles, ShieldCheck, Radio, MapPin, Zap, Compass, LogIn, User } from 'lucide-react';
import { LocationContext, UserProfile } from '../types';

interface HeaderProps {
  onStartDemo?: () => void;
  onStartPromptathonDemo?: () => void;
  currentLocation?: LocationContext;
  activeLocation?: string;
  onOpenLocationSelect?: () => void;
  activeDomainCount?: number;
  onOpenAgenticMode?: () => void;
  onLaunchScenario?: (scenarioKey: string) => void;
  currentUser?: UserProfile | null;
  onOpenSignIn?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onStartDemo,
  onStartPromptathonDemo,
  currentLocation,
  activeLocation,
  onOpenLocationSelect,
  onOpenAgenticMode,
  currentUser,
  onOpenSignIn,
}) => {
  const handleDemo = onStartDemo || onStartPromptathonDemo || (() => {});
  const locationText = currentLocation?.address || activeLocation || '4th & Market Transit Hub, San Francisco';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-cyan-950/60 bg-slate-950/80 backdrop-blur-xl px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Brand & Tagline */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 via-blue-600/30 to-violet-600/20 border border-cyan-400/40 shadow-lg shadow-cyan-950/50">
              <Compass className="w-5 h-5 text-cyan-300 animate-pulse" />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-cyan-100 to-cyan-400 bg-clip-text text-transparent">
                  CIVICPULSE AI
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wider bg-cyan-950/80 border border-cyan-700/50 text-cyan-300">
                  PUBLIC-LIFE COMPANION
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                “Turning everyday public challenges into intelligent everyday actions.”
              </p>
            </div>
          </div>

          {/* Mobile Demo & Sign In Triggers */}
          <div className="flex md:hidden items-center gap-1.5">
            <button
              onClick={onOpenSignIn}
              id="mobile-signin-btn"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs font-semibold"
            >
              {currentUser ? (
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              ) : (
                <LogIn className="w-3.5 h-3.5 text-cyan-400" />
              )}
              <span>{currentUser ? currentUser.name.split(' ')[0] : 'Sign In'}</span>
            </button>
            <button
              onClick={handleDemo}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold shadow-md shadow-cyan-900/40"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Demo</span>
            </button>
          </div>
        </div>

        {/* Status Pills & High-Visibility Actions */}
        <div className="flex items-center flex-wrap gap-2.5 justify-end w-full md:w-auto">
          {/* Location Context Pill */}
          <button
            onClick={onOpenLocationSelect}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-cyan-800/80 text-xs text-slate-300 hover:text-cyan-300 transition-colors"
            title="Change Location Context"
          >
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span className="truncate max-w-[170px] sm:max-w-[210px]">{locationText}</span>
          </button>

          {/* Citizen Sign In / Profile Option */}
          <button
            id="signin-btn"
            onClick={onOpenSignIn}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentUser
                ? 'bg-slate-900/90 border border-cyan-700/60 hover:border-cyan-400 text-cyan-100 shadow-sm'
                : 'bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-600/50 hover:border-cyan-400 text-cyan-200 shadow-sm'
            }`}
            title={currentUser ? `Signed in as ${currentUser.name}` : 'Sign In to Citizen Account'}
          >
            {currentUser ? (
              <>
                {currentUser.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-4 h-4 rounded-full object-cover border border-cyan-400/50"
                  />
                ) : (
                  <div className="w-4 h-4 rounded-full bg-cyan-600 text-[10px] font-bold text-white flex items-center justify-center">
                    {currentUser.name[0]}
                  </div>
                )}
                <span className="max-w-[100px] truncate">{currentUser.name}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Verified Citizen" />
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sign In</span>
              </>
            )}
          </button>

          {/* AI Status Pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400">
            <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>Gemini 3.8 Flash</span>
            <span className="text-slate-600">|</span>
            <ShieldCheck className="w-3 h-3 text-cyan-400" />
            <span className="text-cyan-300/90">Human Control</span>
          </div>

          {/* CivicPilot Agentic Trigger */}
          <button
            onClick={onOpenAgenticMode}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-violet-800/60 hover:border-violet-600 text-violet-300 hover:text-violet-200 text-xs font-medium transition-all"
          >
            <Zap className="w-3.5 h-3.5 text-violet-400" />
            <span>CivicPilot Agent</span>
          </button>

          {/* Grand Promptathon Showcase CTA */}
          <button
            id="promptathon-demo-btn"
            onClick={handleDemo}
            className="group relative inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-violet-600 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-cyan-900/40 hover:shadow-cyan-700/60 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 overflow-hidden"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out"></span>
            <Sparkles className="w-4 h-4 text-cyan-200 group-hover:rotate-12 transition-transform" />
            <span className="tracking-wide">START PROMPTHON DEMO</span>
          </button>
        </div>
      </div>
    </header>
  );
};
