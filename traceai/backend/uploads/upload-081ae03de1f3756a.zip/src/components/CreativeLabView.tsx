import React, { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  HeartHandshake,
  DollarSign,
  Leaf,
  SlidersHorizontal,
  ThumbsUp,
  ArrowRight,
  TrendingUp,
  Share2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { LateralSolution } from '../types';

interface CreativeLabViewProps {
  onSelectSolution?: (solution: LateralSolution) => void;
}

export const CreativeLabView: React.FC<CreativeLabViewProps> = ({ onSelectSolution }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [problemQuery, setProblemQuery] = useState(
    'Bus stop is overcrowded and delivery pallets block the sidewalk wheelchair curb cut.'
  );

  const [solutions, setSolutions] = useState<LateralSolution[]>([
    {
      id: 'sol-1',
      title: 'Tactical "Blue Tape" Boarding Queue Zone',
      category: 'LOW-COST',
      description: 'Mark a high-visibility perimeter on sidewalk with washable chalk/tape reserving a 6-foot clearance lane for wheelchair boarding.',
      feasibility: 'high',
      cost: 'free',
      effort: 'low',
      communityImpact: 'high',
      upvotes: 42,
    },
    {
      id: 'sol-2',
      title: 'Merchant Loading Time Harmony Agreement',
      category: 'COMMUNITY_BASED',
      description: 'Coordinate with adjacent cafe & grocery store to shift commercial pallet offloading to off-peak hours (7:00–7:45 AM).',
      feasibility: 'high',
      cost: 'low',
      effort: 'medium',
      communityImpact: 'high',
      upvotes: 38,
    },
    {
      id: 'sol-3',
      title: 'Autonomous Mobile Ramp Notification Push',
      category: 'CREATIVE',
      description: 'Ping oncoming bus drivers via transit telemetry 2 stops prior, requesting them to kneel the bus on the unobstructed corner.',
      feasibility: 'medium',
      cost: 'low',
      effort: 'low',
      communityImpact: 'high',
      upvotes: 56,
    },
    {
      id: 'sol-4',
      title: 'Community Green-Box Tactile Planter Barrier',
      category: 'SUSTAINABLE',
      description: 'Install low-cost recycled timber planter boxes with drought-tolerant flora preventing unauthorized commercial pallets from encroaching.',
      feasibility: 'high',
      cost: 'medium',
      effort: 'medium',
      communityImpact: 'high',
      upvotes: 29,
    },
    {
      id: 'sol-5',
      title: 'Immediate Micro-Reroute to Stevenson Walkway',
      category: 'PRACTICAL',
      description: 'Guide passengers to the covered, step-free pedestrian lane 40 meters south, avoiding the crowd surge completely.',
      feasibility: 'high',
      cost: 'free',
      effort: 'low',
      communityImpact: 'medium',
      upvotes: 64,
    },
  ]);

  const handleUpvote = (id: string) => {
    setSolutions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, upvotes: s.upvotes + 1 } : s))
    );
    try {
      confetti({ particleCount: 20, spread: 40 });
    } catch {}
  };

  const filteredSolutions = solutions.filter((s) => {
    if (selectedCategory === 'ALL') return true;
    return s.category === selectedCategory;
  });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-950 via-slate-950 to-slate-900 border border-amber-600/40 p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-950 border border-amber-500/40 text-amber-300 shadow-md">
              <Lightbulb className="w-7 h-7 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">Creative Civic Solutions Lab</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                  LATERAL URBAN REASONING
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                "How can we solve this public-life challenge differently, cheaply, or communally?"
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Problem Context Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
        <label className="block text-xs font-semibold text-slate-300">
          Civic Challenge Under Brainstorming:
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={problemQuery}
            onChange={(e) => setProblemQuery(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'ALL', label: 'All Approaches' },
          { id: 'PRACTICAL', label: 'Practical' },
          { id: 'LOW-COST', label: 'Low-Cost' },
          { id: 'CREATIVE', label: 'Creative' },
          { id: 'COMMUNITY_BASED', label: 'Community-Based' },
          { id: 'SUSTAINABLE', label: 'Sustainable' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              selectedCategory === cat.id
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Solutions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredSolutions.map((sol) => (
          <div
            key={sol.id}
            className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-700/60 transition-all flex flex-col justify-between space-y-4 shadow-lg group"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                  {sol.category.replace('_', ' ')}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                  <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                  {sol.upvotes} Citizens Backing
                </span>
              </div>

              <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                {sol.title}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {sol.description}
              </p>
            </div>

            <div className="space-y-3 pt-2 border-t border-slate-800/80">
              <div className="grid grid-cols-4 gap-1 text-[10px] text-center">
                <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block">Feasibility</span>
                  <strong className="text-slate-200 uppercase">{sol.feasibility}</strong>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block">Cost</span>
                  <strong className="text-emerald-300 uppercase">{sol.cost}</strong>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block">Effort</span>
                  <strong className="text-slate-200 uppercase">{sol.effort}</strong>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block">Impact</span>
                  <strong className="text-amber-300 uppercase">{sol.communityImpact}</strong>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => handleUpvote(sol.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 hover:text-amber-300 transition-colors"
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Support This Idea</span>
                </button>

                <button
                  onClick={() => {
                    if (onSelectSolution) onSelectSolution(sol);
                  }}
                  className="flex items-center gap-1 text-xs font-semibold text-amber-400 hover:text-amber-300"
                >
                  <span>Act on Solution</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
