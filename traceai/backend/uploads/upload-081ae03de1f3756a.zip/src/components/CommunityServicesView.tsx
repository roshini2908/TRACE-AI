import React, { useState } from 'react';
import {
  Users,
  Search,
  MapPin,
  Clock,
  CheckCircle2,
  FileCheck,
  ShieldCheck,
  ExternalLink,
  Navigation,
  Sparkles,
} from 'lucide-react';
import { DEMO_CIVIC_SERVICES } from '../data/civicKnowledge';

interface CommunityServicesViewProps {
  onAskAboutService: (serviceName: string) => void;
}

export const CommunityServicesView: React.FC<CommunityServicesViewProps> = ({
  onAskAboutService,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = ['ALL', 'library', 'health', 'administrative', 'waste', 'park'];

  const services = DEMO_CIVIC_SERVICES;

  const filteredServices = services.filter((s) => {
    const matchCat = selectedCategory === 'ALL' || s.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchQuery =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.nextAction && s.nextAction.toLowerCase().includes(searchQuery.toLowerCase())) ||
      s.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchQuery;
  });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-950 via-slate-950 to-slate-900 border border-blue-700/40 p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-blue-950 border border-blue-500/40 text-blue-300 shadow-md">
              <Users className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">Verified Community Services Directory</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-700">
                  PUBLIC DIRECTORY
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Reliable public amenities, health centers, libraries, and civic support verified through official records.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Epistemic Honesty Grounding Note */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300">
        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        <span>
          <strong>Grounding Audit:</strong> Operating hours and accessibility standards verified against municipal records within the last 48 hours. Holiday schedules may vary.
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search public services, notary desks, clinics, recycling centers…"
            className="w-full bg-transparent text-xs sm:text-sm text-slate-100 placeholder-slate-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs capitalize transition-all shrink-0 ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredServices.map((service) => (
          <div
            key={service.id}
            className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-700/60 transition-all flex flex-col justify-between space-y-4 shadow-lg group"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-950 text-blue-300 border border-blue-800">
                  {service.category}
                </span>
                <span className="text-xs font-semibold text-emerald-400">
                  {service.wheelchairAccessible ? 'Step-Free Ramp Verified' : 'Standard Entrance'}
                </span>
              </div>

              <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                {service.name}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {service.nextAction}
              </p>
              {service.requirements && service.requirements.length > 0 && (
                <div className="text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-300">Requirements:</span> {service.requirements.join(' • ')}
                </div>
              )}

              <div className="space-y-1 pt-2 border-t border-slate-800/80 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>{service.address} ({service.distance})</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-200">{service.hours}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-[11px] font-mono text-cyan-400">
                {service.contact ? `Contact: ${service.contact}` : 'Verified Public Amenity'}
              </span>
              <button
                onClick={() => onAskAboutService(service.name)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 text-xs font-semibold transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                <span>Ask CivicPulse</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
