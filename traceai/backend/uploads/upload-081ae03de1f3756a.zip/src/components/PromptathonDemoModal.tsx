import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  X,
  Play,
  RotateCcw,
  CheckCircle2,
  Eye,
  Layers,
  Cpu,
  Database,
  Send,
  ShieldCheck,
  MousePointerClick,
  Bus,
  MapPin,
  ArrowRight,
  FileText,
  Navigation,
  ThumbsUp,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PROMPTATHON_DEMO_SCENARIO } from '../data/sampleScenarios';
import { CivicPulseResponse, PipelineExecutionLog } from '../types';

interface PromptathonDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onViewRouteOnMap: () => void;
  onOpenReportDraft: () => void;
}

export const PromptathonDemoModal: React.FC<PromptathonDemoModalProps> = ({
  isOpen,
  onClose,
  onViewRouteOnMap,
  onOpenReportDraft,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlayingAuto, setIsPlayingAuto] = useState(false);
  const [userSelectedOption, setUserSelectedOption] = useState<string | null>(null);

  const scenario = PROMPTATHON_DEMO_SCENARIO;
  const demoData = scenario.sampleResponse;

  const steps = [
    {
      layerNumber: 1,
      name: 'LAYER 1 — USER EXPERIENCE',
      tagline: 'Multi-Modal Signal Intake (Voice / Text / Photo / Location)',
      icon: Eye,
      color: 'from-cyan-500 to-blue-600',
      description: 'The citizen reports an urgent public bottleneck using live voice dictation and automated geolocation coordinates.',
      activeData: {
        rawInput: `"${scenario.query}"`,
        modality: 'VOICE (Speech-to-Text Stream)',
        location: scenario.locationName,
        coordinates: '37.7858° N, 122.4065° W [Stop #1492]',
      },
    },
    {
      layerNumber: 2,
      name: 'LAYER 2 — INPUT PROCESSING',
      tagline: 'Entity Extraction, Vision Ingestion & Signal Normalization',
      icon: Layers,
      color: 'from-blue-600 to-indigo-600',
      description: 'The input processor parses natural language signals, identifies physical obstacles, and validates spatial boundary buffers.',
      activeData: {
        extractedIntent: 'MOBILITY + SAFETY ISSUE REPORTING',
        identifiedEntities: [
          'Location: 4th & Market Stop #1492',
          'Condition: Overcrowding & Physical Ramp Obstruction',
          'Requirement: Step-Free Accessible Transit Route',
        ],
        urgencyScore: 'HIGH (Imminent transit passenger hazard)',
      },
    },
    {
      layerNumber: 3,
      name: 'LAYER 3 — AI ORCHESTRATION',
      tagline: 'Intent Classifier, Priority Detection & Prompt Routing',
      icon: Cpu,
      color: 'from-indigo-600 to-violet-600',
      description: 'The Orchestrator evaluates the multi-intent payload, activates the Transport & Accessibility specialist prompts, and selects tools.',
      activeData: {
        domainsInvoked: 'TRANSPORT_MOBILITY + SMART_SOLUTIONS',
        toolsSelected: ['getAccessibleRoutes', 'getLocationContext', 'searchKnowledge'],
        responseMode: 'RECOMMEND + DRAFT (Dual action path)',
      },
    },
    {
      layerNumber: 4,
      name: 'LAYER 4 — MODELS & KNOWLEDGE',
      tagline: 'Gemini 3.8 Flash Multimodal Reasoning & Verified Municipal Data',
      icon: Database,
      color: 'from-violet-600 to-purple-600',
      description: 'Gemini cross-references live sidewalk gradients, transit schedule feeds, and verified ADA municipal guidelines.',
      activeData: {
        model: 'Gemini 3.8 Flash (Server-Side)',
        groundedSources: [
          'Municipal Transit Authority Guidelines §14-B',
          'Priority 1 Urban Accessibility Code (90-min clearance)',
        ],
        spatialResult: 'Alternate Level Shuttle Stop #1510 detected 180m east via flat Stevenson corridor.',
      },
    },
    {
      layerNumber: 5,
      name: 'LAYER 5 — RESPONSE & ACTION ENGINE',
      tagline: 'Multi-Option Synthesis & Tradeoff Comparison',
      icon: Send,
      color: 'from-purple-600 to-cyan-500',
      description: 'CivicPulse formulates 3 distinct graded alternatives with duration, step-free classification, and confidence scoring.',
      activeData: {
        situation: demoData.situation,
        options: demoData.recommendations.map((r) => `${r.title} — ${r.duration} (${r.accessibilityGrade})`),
        primaryConfidence: `${demoData.confidence}%`,
      },
    },
    {
      layerNumber: 6,
      name: 'LAYER 6 — SAFETY & HUMAN CONTROL',
      tagline: 'Epistemic Honesty Audit & Citizen Approval Gate',
      icon: ShieldCheck,
      color: 'from-emerald-500 to-teal-600',
      description: 'Facts are separated from inferences. The automated civic report is drafted, but CANNOT be dispatched without citizen authorization.',
      activeData: {
        verifiedFactsCount: `${demoData.verifiedFacts.length} verified facts confirmed`,
        inferencesCount: `${demoData.inferences.length} model deductions qualified`,
        epistemicStatus: 'Detected / Needs Verification',
        humanGate: 'MANDATORY APPROVAL: Report drafted in workspace awaiting review',
      },
    },
    {
      layerNumber: 7,
      name: 'LAYER 7 — USER ACTION',
      tagline: 'Actuation: Interactive Route Navigation & Municipal Dispatch',
      icon: MousePointerClick,
      color: 'from-amber-500 to-cyan-500',
      description: 'Citizen chooses their preferred step-free route, reviews the pre-filled Priority 1 report, or explores creative community solutions.',
      activeData: {
        action1: 'Interactive Turn-by-Turn Map: 4-minute level walk to Stop #1510',
        action2: 'Civic Report Draft: Priority 1-A Ramp Clearance to Transit Board',
        action3: 'Creative Alternative: Press Blue Callbox for driver kneeling alert',
      },
    },
  ];

  // Auto-run stepper
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlayingAuto && isOpen) {
      timer = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlayingAuto(false);
            try {
              confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
            } catch {}
            return prev;
          }
        });
      }, 3500);
    }
    return () => clearInterval(timer);
  }, [isPlayingAuto, isOpen, steps.length]);

  if (!isOpen) return null;

  const current = steps[currentStep];
  const StepIcon = current.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-xl animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-cyan-500/40 p-5 sm:p-8 shadow-2xl shadow-cyan-950/80 text-slate-100 my-6 max-h-[92vh] flex flex-col">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-md shadow-cyan-900/40">
              <Sparkles className="w-5 h-5 text-white animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-xl font-bold bg-gradient-to-r from-white via-cyan-100 to-cyan-400 bg-clip-text text-transparent">
                  PROMPTATHON GRAND DEMONSTRATION
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                  LIVE 7-LAYER SHOWCASE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Evaluating the complete CivicPulse AI conceptual architecture end-to-end.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close showcase"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Progress Bar */}
        <div className="py-4 border-b border-slate-800/80 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[620px] gap-2">
            {steps.map((s, idx) => {
              const isPast = idx < currentStep;
              const isCurrent = idx === currentStep;
              return (
                <button
                  key={s.layerNumber}
                  onClick={() => {
                    setCurrentStep(idx);
                    setIsPlayingAuto(false);
                  }}
                  className={`flex-1 flex flex-col items-center text-center p-2 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-cyan-950/80 border-cyan-400/90 shadow-lg shadow-cyan-950/60 scale-[1.03]'
                      : isPast
                      ? 'bg-slate-900/90 border-slate-700'
                      : 'bg-slate-950 border-slate-800/60 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold mb-1">
                    {isPast ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <span className={isCurrent ? 'text-cyan-300 font-extrabold' : 'text-slate-500'}>
                        {s.layerNumber}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-bold text-slate-200 line-clamp-1">
                    L{s.layerNumber}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Layer Showcase Body */}
        <div className="flex-1 overflow-y-auto py-5 space-y-4">
          {/* Layer Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-cyan-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-slate-900 border border-cyan-500/40 text-cyan-300 shadow-md">
                <StepIcon className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  {current.name}
                </span>
                <h3 className="text-base sm:text-lg font-bold text-slate-100">
                  {current.tagline}
                </h3>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-mono text-slate-400">
                Step {currentStep + 1} of 7
              </span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed px-1">
            {current.description}
          </p>

          {/* Layer-Specific Live Telemetry Display */}
          <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Live Architecture Ingestion & Signal Telemetry:
            </span>

            {/* Content variations per layer */}
            {currentStep === 0 && (
              <div className="space-y-2 text-xs">
                <p><strong className="text-slate-200">Raw Citizen Audio Input:</strong> {current.activeData.rawInput}</p>
                <p><strong className="text-slate-200">Input Modality:</strong> <span className="text-cyan-300">{current.activeData.modality}</span></p>
                <p><strong className="text-slate-200">Observed Geographic Context:</strong> {current.activeData.location}</p>
                <p><strong className="text-slate-200">GPS Coordinates:</strong> <span className="font-mono text-slate-400">{current.activeData.coordinates}</span></p>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-2 text-xs">
                <p><strong className="text-slate-200">Classified Intent:</strong> <span className="text-amber-300 font-bold">{current.activeData.extractedIntent}</span></p>
                <p><strong className="text-slate-200">Urgency Level:</strong> <span className="text-rose-400 font-bold">{current.activeData.urgencyScore}</span></p>
                <div>
                  <strong className="text-slate-200">Extracted Urban Entities:</strong>
                  <ul className="mt-1 space-y-1 text-slate-300 pl-4 list-disc">
                    {(current.activeData.identifiedEntities as string[]).map((e, i) => (
                      <li key={i}>{e}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-2 text-xs">
                <p><strong className="text-slate-200">Activated Domains:</strong> <span className="text-cyan-300 font-bold">{current.activeData.domainsInvoked}</span></p>
                <p><strong className="text-slate-200">Response Mode Selected:</strong> <span className="text-violet-300 font-mono">{current.activeData.responseMode}</span></p>
                <div>
                  <strong className="text-slate-200">Autonomous Tool Calls Dispatched:</strong>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {(current.activeData.toolsSelected as string[]).map((t, i) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-900 border border-violet-700/60 text-violet-300 font-mono text-[11px]">
                        {t}()
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-2 text-xs">
                <p><strong className="text-slate-200">Inference Engine:</strong> <span className="text-emerald-400 font-bold">{current.activeData.model}</span></p>
                <p><strong className="text-slate-200">Verified Knowledge Grounding:</strong></p>
                <ul className="space-y-1 text-slate-300 pl-4 list-disc">
                  {(current.activeData.groundedSources as string[]).map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
                <p className="text-cyan-300 mt-2 font-medium">✓ {current.activeData.spatialResult}</p>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-2.5 text-xs">
                <p><strong className="text-slate-200">Synthesized Situation:</strong> {current.activeData.situation}</p>
                <p><strong className="text-slate-200">Generated Path Matrix:</strong></p>
                <div className="space-y-1.5">
                  {(current.activeData.options as string[]).map((opt, i) => (
                    <div key={i} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 font-medium">
                      {opt}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 5 && (
              <div className="space-y-2.5 text-xs">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Epistemic Audit & Human Control Verification</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-emerald-900 text-emerald-300">
                    ✓ {current.activeData.verifiedFactsCount}
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-blue-900 text-cyan-300">
                    ~ {current.activeData.inferencesCount}
                  </div>
                </div>
                <p className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/60 text-amber-200">
                  ⚠️ {current.activeData.humanGate}
                </p>
              </div>
            )}

            {currentStep === 6 && (
              <div className="space-y-3 text-xs">
                <p className="text-slate-200 font-semibold">
                  All 7 architectural layers have executed. The citizen now exercises direct control:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      onViewRouteOnMap();
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-cyan-950 hover:bg-cyan-900/90 border border-cyan-700 text-left space-y-1 transition-all"
                  >
                    <div className="flex items-center gap-2 text-cyan-300 font-bold">
                      <Navigation className="w-4 h-4" />
                      <span>View Route on Interactive Map</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Inspect the 4-min step-free Stevenson flat corridor to Stop #1510.
                    </p>
                  </button>

                  <button
                    onClick={() => {
                      onOpenReportDraft();
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-amber-950 hover:bg-amber-900/90 border border-amber-700 text-left space-y-1 transition-all"
                  >
                    <div className="flex items-center gap-2 text-amber-300 font-bold">
                      <FileText className="w-4 h-4" />
                      <span>Review & Approve Civic Report</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Inspect pre-filled Priority 1 ramp clearance ticket for municipal transit dispatch.
                    </p>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Stepper Controls Footer */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlayingAuto(!isPlayingAuto)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-200 font-semibold transition-all"
            >
              <Play className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isPlayingAuto ? 'Pause Auto Walkthrough' : 'Auto Play 7 Layers'}</span>
            </button>

            <button
              onClick={() => {
                setCurrentStep(0);
                setIsPlayingAuto(false);
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-slate-200"
              title="Restart from Layer 1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <button
                onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-300"
              >
                Previous Layer
              </button>
            )}

            {currentStep < steps.length - 1 ? (
              <button
                onClick={() => setCurrentStep((prev) => Math.min(steps.length - 1, prev + 1))}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs sm:text-sm font-semibold shadow-md shadow-cyan-950/60"
              >
                <span>Advance to Layer {currentStep + 2}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold shadow-md"
              >
                Done with Grand Showcase
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
