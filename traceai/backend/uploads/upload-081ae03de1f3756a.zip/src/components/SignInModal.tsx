import React, { useState } from 'react';
import {
  X,
  LogIn,
  UserPlus,
  ShieldCheck,
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  Sparkles,
  MapPin,
} from 'lucide-react';
import { UserProfile } from '../types';

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignIn: (user: UserProfile) => void;
  currentUser?: UserProfile | null;
  onSignOut?: () => void;
}

export const SignInModal: React.FC<SignInModalProps> = ({
  isOpen,
  onClose,
  onSignIn,
  currentUser,
  onSignOut,
}) => {
  const [tab, setTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [district, setDistrict] = useState('Downtown / SoMa');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  // Handle standard form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    if (!password || password.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const displayName =
        tab === 'signup' && name.trim()
          ? name.trim()
          : email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

      const profile: UserProfile = {
        id: `user-${Date.now()}`,
        name: displayName,
        email: email.trim().toLowerCase(),
        role: 'Citizen',
        verifiedCitizen: true,
        district: district,
        citizenBadgeId: `SF-CP-${Math.floor(1000 + Math.random() * 9000)}`,
      };

      onSignIn(profile);
      setLoading(false);
      onClose();
    }, 400);
  };

  // Quick Sign In with Google
  const handleGoogleSignIn = () => {
    setLoading(true);
    setError(null);

    setTimeout(() => {
      const profile: UserProfile = {
        id: `google-${Date.now()}`,
        name: 'Alex Rivera',
        email: 'alex.rivera.civic@gmail.com',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        role: 'Citizen',
        verifiedCitizen: true,
        district: 'Market Corridor / SoMa',
        citizenBadgeId: 'SF-CP-8842',
      };

      onSignIn(profile);
      setLoading(false);
      onClose();
    }, 400);
  };

  // Quick 1-click Demo Persona
  const handleDemoSignIn = (personaName: string, role: UserProfile['role'], districtName: string) => {
    setLoading(true);
    setTimeout(() => {
      const profile: UserProfile = {
        id: `demo-${Date.now()}`,
        name: personaName,
        email: `${personaName.toLowerCase().replace(/\s+/g, '.')}@sf-citizen.org`,
        role: role,
        verifiedCitizen: true,
        district: districtName,
        citizenBadgeId: `SF-CP-${Math.floor(2000 + Math.random() * 8000)}`,
      };

      onSignIn(profile);
      setLoading(false);
      onClose();
    }, 300);
  };

  return (
    <div
      id="signin-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="signin-modal-content"
        className="relative w-full max-w-md bg-slate-900 border border-cyan-900/50 rounded-2xl shadow-2xl shadow-cyan-950/60 overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/80 border border-cyan-500/30 text-cyan-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {currentUser ? 'Citizen Account' : 'CivicPulse Sign In'}
              </h2>
              <p className="text-xs text-slate-400">
                {currentUser
                  ? 'Your verified public-life profile & credentials'
                  : 'Sign in to authorize 311 reports & sync preferences'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ALREADY SIGNED IN VIEW */}
        {currentUser ? (
          <div className="p-6 space-y-6">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-3.5">
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-12 h-12 rounded-full border border-cyan-400/40 object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-bold text-base">
                  {currentUser.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white truncate">{currentUser.name}</h3>
                  {currentUser.verifiedCitizen && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800">
                      <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                      Verified
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 truncate">{currentUser.email}</p>
                {currentUser.citizenBadgeId && (
                  <p className="text-[11px] font-mono text-cyan-400 mt-0.5">
                    Badge: {currentUser.citizenBadgeId}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1.5 border-b border-slate-800/80">
                <span className="text-slate-400">Account Role</span>
                <span className="font-semibold text-slate-200">{currentUser.role}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800/80">
                <span className="text-slate-400">Assigned District</span>
                <span className="font-semibold text-slate-200">{currentUser.district || 'Downtown'}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-400">Municipal Authorization</span>
                <span className="text-emerald-400 font-semibold">Active (Human-in-the-Loop)</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
              >
                Close
              </button>
              {onSignOut && (
                <button
                  onClick={() => {
                    onSignOut();
                    onClose();
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-semibold transition-colors"
                >
                  Sign Out
                </button>
              )}
            </div>
          </div>
        ) : (
          /* NOT SIGNED IN: FORM VIEW */
          <div className="p-6 space-y-5">
            {/* Quick Demo Citizen Quick-Action */}
            <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-800/40 space-y-2">
              <div className="flex items-center justify-between text-xs text-cyan-300 font-semibold">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  Instant Demo Sign In
                </span>
                <span className="text-[10px] text-cyan-400/80 font-mono">1-Click</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Test the full citizen verification workflow without creating credentials:
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleDemoSignIn('Alex Rivera', 'Citizen', 'Downtown / SoMa')}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-cyan-900/60 hover:bg-cyan-800 text-cyan-100 text-xs font-medium border border-cyan-700/50 transition-colors text-left truncate"
                >
                  Alex Rivera (Citizen)
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoSignIn('Jordan Lee', 'Municipal Advocate', 'Mission Corridor')}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-blue-100 text-xs font-medium border border-blue-700/50 transition-colors text-left truncate"
                >
                  Jordan Lee (Advocate)
                </button>
              </div>
            </div>

            {/* Google One-Click Sign In */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-semibold text-xs transition-all shadow-sm active:scale-[0.99]"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Divider */}
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-800"></div>
              </div>
              <span className="relative px-3 bg-slate-900 text-[11px] text-slate-500 uppercase tracking-wider">
                Or with Email
              </span>
            </div>

            {/* Tab switch: Sign In vs Sign Up */}
            <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setTab('signin');
                  setError(null);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  tab === 'signin'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setTab('signup');
                  setError(null);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  tab === 'signup'
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Register Citizen ID
              </button>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs">
                {error}
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-3.5">
              {tab === 'signup' && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Morgan Hayes"
                        className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Home District
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <select
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        <option value="Downtown / SoMa">Downtown / SoMa</option>
                        <option value="Mission Corridor">Mission Corridor</option>
                        <option value="Richmond / Sunset">Richmond / Sunset</option>
                        <option value="Castro / Upper Market">Castro / Upper Market</option>
                        <option value="Bayview / Hunters Point">Bayview / Hunters Point</option>
                      </select>
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="citizen@example.com"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">Password</label>
                  {tab === 'signin' && (
                    <button
                      type="button"
                      onClick={() => setError('Password reset instructions sent to your email.')}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-3.5 h-3.5 rounded bg-slate-950 border-slate-800 text-cyan-500 focus:ring-0"
                  />
                  <span className="text-[11px] text-slate-400">Keep me signed in</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-950/60 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <span>Authenticating...</span>
                ) : tab === 'signin' ? (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Sign In</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create Citizen ID</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
