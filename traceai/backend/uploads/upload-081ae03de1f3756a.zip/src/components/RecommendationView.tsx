import React, { useState } from 'react';
import {
  ShieldCheck,
  Clock,
  Sparkles,
  MapPin,
  FileText,
  HelpCircle,
  CheckCircle,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Leaf,
  Navigation,
  ThumbsUp,
  Share2,
  ExternalLink,
  Info,
} from 'lucide-react';
import { CivicPulseResponse, RecommendationOption } from '../types';

interface RecommendationViewProps {
  response?: CivicPulseResponse | null;
  activeQuery?: string;
  isProcessing?: boolean;
  onViewRoute?: () => void;
  onPrepareReport?: () => void;
  onOpenCreative?: () => void;
  onAskFollowUp?: (text: string) => void;
  onApproveAction?: () => void;
}

export const RecommendationView: React.FC<RecommendationViewProps> = ({
  response,
  activeQuery,
  isProcessing = false,
  onViewRoute,
  onPrepareReport,
  onOpenCreative,
  onAskFollowUp,
  onApproveAction,
}) => {
  const [showWhy, setShowWhy] = useState(false);
  const [approvedOptionId, setApprovedOptionId] = useState<string | null>(null);
  const [followUpText, setFollowUpText] = useState('');

  const urgencyColors: Record<string, string> = {
    low: 'bg-blue-950/80 text-blue-300 border-blue-800',
    medium: 'bg-amber-950/80 text-amber-300 border-amber-800',
    high: 'bg-orange-950/80 text-orange-300 border-orange-800',
    critical: 'bg-red-950/80 text-red-300 border-red-800 animate-pulse',
  };

  const handleSelectOption = (opt: RecommendationOption) => {
    setApprovedOptionId(opt.id);
    if (onApproveAction) {
      onApproveAction();
    }
  };

  // Safe string helper for any unknown object value from LLM
  const safeString = (val: any, fallback = ''): string => {
    if (val === null || val === undefined) return fallback;
    if (typeof val === 'string') return val;
    if (typeof val === 'number') return String(val);
    if (typeof val === 'object') {
      return val.text || val.fact || val.inference || val.title || val.description || val.name || JSON.stringify(val);
    }
    return String(val);
  };

  // If currently processing a query, display live progressive answering state
  if (isProcessing) {
    return (
      <div className="w-full space-y-4 animate-fade-in">
        <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-cyan-500/50 p-5 sm:p-6 shadow-2xl shadow-cyan-950/40 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-cyan-800/40">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                CivicPulse AI Engine • Synthesizing Answer
              </span>
            </div>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-cyan-950 text-cyan-300 border border-cyan-700/60">
              Live Reasoning
            </span>
          </div>

          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Answering Your Question:
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white mt-1">
              "{activeQuery || 'Your civic question'}"
            </h3>
          </div>

          <div className="space-y-2.5 pt-2">
            <div className="flex items-center gap-2.5 text-xs text-slate-300">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
              <span>Analyzing intent & spatial constraints with Gemini AI...</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full animate-pulse w-3/4"></div>
            </div>
            <p className="text-[11px] text-slate-400">
              Cross-referencing municipal regulations, accessibility guidelines, and local corridor alternatives.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!response) {
    return (
      <div className="w-full p-6 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-2 text-slate-400">
        <Sparkles className="w-6 h-6 text-cyan-400 mx-auto" />
        <p className="text-sm font-semibold text-slate-200">Ready for your civic question</p>
        <p className="text-xs">Ask a question above or choose a quick action to receive tailored guidance.</p>
      </div>
    );
  }

  // Safe confidence calculation (ensure 0..100)
  const rawConf = Number(response.confidence);
  const normalizedConfidence = isNaN(rawConf)
    ? 92
    : rawConf <= 1
    ? Math.round(rawConf * 100)
    : Math.min(Math.round(rawConf), 99);

  const rawUrgency = (response.urgency || 'medium').toLowerCase();
  const urgencyColor = urgencyColors[rawUrgency] || urgencyColors.medium;

  const domainsList = Array.isArray(response.domains)
    ? response.domains
    : typeof response.domains === 'string'
    ? [response.domains]
    : ['COMMUNITY_SERVICES'];

  const factsList = Array.isArray(response.verifiedFacts) ? response.verifiedFacts : [];
  const inferencesList = Array.isArray(response.inferences) ? response.inferences : [];
  const recommendationsList = Array.isArray(response.recommendations) ? response.recommendations : [];
  const sourcesList = Array.isArray(response.sources) ? response.sources : [];

  return (
    <div className="w-full space-y-4 animate-fade-in">
      {/* Active Question Banner if available */}
      {activeQuery && (
        <div className="px-4 py-2.5 rounded-xl bg-cyan-950/50 border border-cyan-700/40 text-xs flex items-center justify-between gap-2 shadow-sm">
          <div className="flex items-center gap-2 truncate">
            <span className="font-bold text-cyan-300 uppercase tracking-wider text-[10px] shrink-0">
              Answer For:
            </span>
            <span className="text-slate-200 truncate font-medium">"{activeQuery}"</span>
          </div>
          <span className="text-[10px] text-cyan-400/80 shrink-0 font-mono">Verified Solution</span>
        </div>
      )}

      {/* Top Situation Header Card */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border border-slate-800 p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div className="flex items-center flex-wrap gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-cyan-950/90 text-cyan-300 border border-cyan-700/60 uppercase tracking-wider">
              {safeString(response.mode, 'RECOMMEND')}
            </span>
            <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border uppercase tracking-wider ${urgencyColor}`}>
              Urgency: {rawUrgency}
            </span>
            {domainsList.map((dom, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-slate-900 text-slate-300 border border-slate-700"
              >
                {safeString(dom).replace(/_/g, ' ')}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              AI Confidence: <strong className="text-cyan-300">{normalizedConfidence}%</strong>
            </span>
          </div>
        </div>

        <div className="pt-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-100 mb-1">
            {safeString(response.situation, 'Public Life Recommendation')}
          </h3>
        </div>
      </div>

      {/* "What I Understand" Card */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 sm:p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
          <Info className="w-4 h-4" />
          <span>What I Understand</span>
        </div>
        <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
          {safeString(response.whatIUnderstand)}
        </p>

        {/* Epistemic Differentiation: Verified Facts vs Inferences */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
          {/* Verified Facts */}
          <div className="p-3 rounded-xl bg-slate-950/90 border border-emerald-900/40 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Verified Facts Grounded:</span>
            </div>
            <ul className="space-y-1 text-slate-300">
              {factsList.map((fact, idx) => (
                <li key={idx} className="flex items-start gap-1.5 text-[11px]">
                  <span className="text-emerald-400 shrink-0">•</span>
                  <span>{safeString(fact)}</span>
                </li>
              ))}
              {factsList.length === 0 && (
                <li className="text-[11px] text-slate-400 italic">Grounded in public service standards.</li>
              )}
            </ul>
          </div>

          {/* Inferences */}
          <div className="p-3 rounded-xl bg-slate-950/90 border border-blue-900/40 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Model Inferences & Tradeoffs:</span>
            </div>
            <ul className="space-y-1 text-slate-300">
              {inferencesList.map((inf, idx) => (
                <li key={idx} className="flex items-start gap-1.5 text-[11px]">
                  <span className="text-cyan-400 shrink-0">•</span>
                  <span>{safeString(inf)}</span>
                </li>
              ))}
              {inferencesList.length === 0 && (
                <li className="text-[11px] text-slate-400 italic">Tradeoffs optimized for accessibility.</li>
              )}
            </ul>
          </div>
        </div>
      </div>

      {/* Recommended Action Options (A, B, C) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Recommended Options ({recommendationsList.length})
            </span>
            <span className="text-[11px] text-slate-500">Compare tradeoffs and choose action</span>
          </div>
          <button
            onClick={() => setShowWhy(!showWhy)}
            className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Why this recommendation?</span>
            {showWhy ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Expandable "Why this recommendation?" box */}
        {showWhy && (
          <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-700/50 text-xs text-cyan-200 leading-relaxed animate-fade-in flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 shrink-0 text-cyan-400 mt-0.5" />
            <div>
              <p className="font-semibold text-cyan-300 mb-0.5">Decision Engine Rationale:</p>
              <p className="text-slate-200">{safeString(response.explanationWhy)}</p>
              <p className="text-[10px] text-cyan-400/80 mt-1">
                Grounded in user accessibility profile, low-carbon transit priority, and verified municipal data.
              </p>
            </div>
          </div>
        )}

        {/* Options Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {recommendationsList.map((opt, idx) => {
            const isApproved = approvedOptionId === opt.id;
            const optConf = Number(opt.confidence);
            const optConfidence = isNaN(optConf)
              ? 90
              : optConf <= 1
              ? Math.round(optConf * 100)
              : Math.min(Math.round(optConf), 99);

            return (
              <div
                key={opt.id || idx}
                className={`relative flex flex-col justify-between p-4 rounded-2xl border transition-all duration-200 ${
                  isApproved
                    ? 'bg-gradient-to-b from-cyan-950/80 to-slate-900 border-cyan-400/90 shadow-xl shadow-cyan-950/60'
                    : 'bg-slate-900/90 hover:bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-[11px] font-bold text-cyan-400 tracking-wider">
                      OPTION {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800">
                      {optConfidence}% Confidence
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-100 mb-1.5">{safeString(opt.title)}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">{safeString(opt.description)}</p>

                  <div className="space-y-1.5 py-2 border-t border-slate-800/80 text-[11px]">
                    {opt.duration && (
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-500">Duration:</span>
                        <span className="font-medium text-cyan-300">{safeString(opt.duration)}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-500">Accessibility:</span>
                      <span className="font-medium text-emerald-300">{safeString(opt.accessibilityGrade, 'Standard')}</span>
                    </div>
                    {opt.carbonImpact && (
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-500">Carbon Impact:</span>
                        <span className="font-medium text-teal-300 flex items-center gap-1">
                          <Leaf className="w-3 h-3 text-teal-400" />
                          {safeString(opt.carbonImpact)}
                        </span>
                      </div>
                    )}
                    {opt.tradeoffs && (
                      <div className="pt-1 text-[10px] text-slate-400 italic">
                        Tradeoff: {safeString(opt.tradeoffs)}
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    onClick={() => handleSelectOption(opt)}
                    className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      isApproved
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'bg-cyan-950 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-800/70 hover:border-cyan-600'
                    }`}
                  >
                    {isApproved ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Selected & Approved</span>
                      </>
                    ) : (
                      <>
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>Choose This Path</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Suggested Actions Bar */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-950 border border-cyan-900/40 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
            Next Actions (Human Approval Required)
          </span>
          <span className="text-[11px] text-slate-400">Choose to actuate recommendation</span>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          {onViewRoute && (
            <button
              onClick={onViewRoute}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-950/60 transition-all"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>View Route on Interactive Map</span>
            </button>
          )}

          {onPrepareReport && (
            <button
              onClick={onPrepareReport}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all"
            >
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Review Civic Issue Report Draft</span>
            </button>
          )}

          {onOpenCreative && (
            <button
              onClick={onOpenCreative}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-950/80 hover:bg-violet-900 text-violet-300 border border-violet-800 text-xs font-semibold transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>Explore Creative Lab Solutions</span>
            </button>
          )}
        </div>
      </div>

      {/* Verified Knowledge Sources Footer */}
      {sourcesList.length > 0 && (
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-900 text-xs text-slate-400 space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Verified Data Grounding Sources:
          </span>
          <div className="flex items-center flex-wrap gap-3">
            {sourcesList.map((src, i) => (
              <div key={i} className="flex items-center gap-1.5 text-[11px] text-slate-300">
                <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
                <span className="font-medium">{safeString(src.name)}</span>
                {src.lastUpdated && <span className="text-slate-600">({safeString(src.lastUpdated)})</span>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

