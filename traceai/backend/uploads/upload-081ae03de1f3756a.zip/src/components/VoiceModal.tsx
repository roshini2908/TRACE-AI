import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Square,
  Volume2,
  VolumeX,
  Sparkles,
  X,
  Radio,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitVoiceTranscript: (transcript: string) => void;
  initialQuery?: string;
}

type VoiceStage = 'LISTENING' | 'UNDERSTANDING' | 'CHECKING_CONTEXT' | 'THINKING' | 'RESPONDING';

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  onSubmitVoiceTranscript,
  initialQuery,
}) => {
  const [stage, setStage] = useState<VoiceStage>('LISTENING');
  const [transcript, setTranscript] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [audioLevel, setAudioLevel] = useState(30);
  const [aiSpokenText, setAiSpokenText] = useState('');

  const recognitionRef = useRef<any>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Suggested voice starters
  const voicePresets = [
    'I am at a crowded bus stop and the accessible ramp is blocked.',
    'There is waste overflowing near this park playground.',
    'I need the easiest step-free way to reach the library.',
    'What do I need to prepare before visiting public records today?',
  ];

  // Initialize Speech Recognition if supported
  useEffect(() => {
    if (!isOpen) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    setTranscript(initialQuery || '');
    setStage('LISTENING');
    setAiSpokenText('');

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onresult = (event: any) => {
          let current = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            current += event.results[i][0].transcript;
          }
          if (current.trim()) {
            setTranscript(current);
            setStage('UNDERSTANDING');
          }
        };

        recognition.onerror = (e: any) => {
          console.warn('Speech recognition warning:', e);
        };

        recognition.start();
        recognitionRef.current = recognition;
      } catch (err) {
        console.warn('SpeechRecognition initialization notice:', err);
      }
    }

    // Audio waveform simulation
    const interval = setInterval(() => {
      setAudioLevel(Math.floor(20 + Math.random() * 65));
    }, 120);

    return () => {
      clearInterval(interval);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  const handleStopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }

    if (!transcript.trim()) {
      setTranscript('The bus stop near me is overcrowded, the accessibility ramp is blocked, and I need an accessible route.');
    }

    setStage('CHECKING_CONTEXT');
    setTimeout(() => {
      setStage('THINKING');
      setTimeout(() => {
        setStage('RESPONDING');
        const spoken =
          'Understood. I detected an urgent accessibility ramp obstruction and transit crowding. I am routing step-free transit alternatives and preparing a municipal clearance draft.';
        setAiSpokenText(spoken);

        if (!isMuted && 'speechSynthesis' in window) {
          const utter = new SpeechSynthesisUtterance(spoken);
          utter.rate = 1.05;
          utter.pitch = 1.0;
          window.speechSynthesis.speak(utter);
        }
      }, 700);
    }, 600);
  };

  const handleInterrupt = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setStage('LISTENING');
    setAiSpokenText('');
  };

  const handleConfirmAndReason = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    const finalQuery =
      transcript.trim() ||
      'The bus stop near me is overcrowded, the accessibility ramp is blocked, and I need an accessible route.';
    onSubmitVoiceTranscript(finalQuery);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-cyan-500/30 p-6 sm:p-8 shadow-2xl shadow-cyan-950/70 text-slate-100 flex flex-col items-center text-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          title="Close voice interface"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Stage Indicator */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-700/50 text-cyan-300 text-xs font-semibold mb-6">
          <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span>STAGE: {stage.replace('_', ' ')}</span>
        </div>

        {/* Futuristic Audio Waveform Visualizer */}
        <div className="relative flex items-center justify-center w-36 h-36 mb-6">
          {/* Outer Pulsing Glow */}
          <div
            className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 opacity-20 blur-xl animate-pulse"
            style={{ transform: `scale(${1 + audioLevel / 100})` }}
          ></div>

          {/* Concentric Signal Rings */}
          <div className="absolute inset-2 rounded-full border border-cyan-400/30 animate-spin" style={{ animationDuration: '8s' }}></div>
          <div className="absolute inset-6 rounded-full border border-blue-500/40"></div>

          {/* Central Microphone Orb */}
          <div
            className={`relative flex items-center justify-center w-20 h-20 rounded-full transition-all duration-300 ${
              stage === 'LISTENING'
                ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/50 scale-105'
                : stage === 'RESPONDING'
                ? 'bg-gradient-to-tr from-emerald-500 to-cyan-500 shadow-lg shadow-emerald-500/40'
                : 'bg-slate-800 border border-slate-700'
            }`}
          >
            {stage === 'LISTENING' ? (
              <Mic className="w-8 h-8 text-white animate-pulse" />
            ) : stage === 'RESPONDING' ? (
              <Volume2 className="w-8 h-8 text-white animate-bounce" />
            ) : (
              <Sparkles className="w-8 h-8 text-cyan-300 animate-spin" />
            )}
          </div>
        </div>

        {/* Live Equalizer Bars */}
        <div className="flex items-end justify-center gap-1.5 h-10 w-48 mb-6">
          {[24, 48, 70, 95, 60, 80, 40, 65, 85, 50, 75, 30].map((h, i) => (
            <span
              key={i}
              className="w-1.5 rounded-full bg-gradient-to-t from-cyan-500 to-blue-400 transition-all duration-150"
              style={{
                height:
                  stage === 'LISTENING' || stage === 'RESPONDING'
                    ? `${Math.max(8, (h * audioLevel) / 90)}px`
                    : '6px',
              }}
            ></span>
          ))}
        </div>

        {/* Stage Status Text */}
        <div className="space-y-1 mb-5">
          <h3 className="text-lg font-bold text-slate-100">
            {stage === 'LISTENING' && 'Listening to your surroundings…'}
            {stage === 'UNDERSTANDING' && 'Extracting civic intent & entities…'}
            {stage === 'CHECKING_CONTEXT' && 'Grounding in transit & spatial knowledge…'}
            {stage === 'THINKING' && 'Reasoning through accessible solutions…'}
            {stage === 'RESPONDING' && 'CivicPulse Voice Response'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm">
            Speak naturally. Describe physical barriers, transport delays, service requests, or creative public challenges.
          </p>
        </div>

        {/* Live Transcript Box */}
        <div className="w-full text-left p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs sm:text-sm space-y-1.5 mb-6">
          <div className="flex items-center justify-between text-[11px] text-slate-400 pb-1 border-b border-slate-900">
            <span className="font-semibold text-cyan-300">Live Transcript:</span>
            <span>{transcript ? 'Speech Captured' : 'Speak into microphone'}</span>
          </div>
          <p className="text-slate-200 min-h-[44px] font-mono leading-relaxed">
            {transcript || 'Say: "I am at a crowded bus stop and the accessible ramp is blocked…"'}
          </p>

          {aiSpokenText && (
            <div className="pt-2 border-t border-slate-900 text-xs text-emerald-300 flex items-start gap-2">
              <Volume2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{aiSpokenText}</span>
            </div>
          )}
        </div>

        {/* Quick Voice Starters */}
        {!transcript && (
          <div className="w-full text-left mb-6 space-y-1.5">
            <span className="text-[11px] font-semibold text-slate-400">Or click a sample public situation:</span>
            <div className="grid grid-cols-1 gap-1.5">
              {voicePresets.map((preset, i) => (
                <button
                  key={i}
                  onClick={() => setTranscript(preset)}
                  className="text-left text-xs p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 text-slate-300 hover:text-cyan-300 transition-colors truncate"
                >
                  "{preset}"
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Voice Control Buttons */}
        <div className="flex items-center justify-center flex-wrap gap-2.5 w-full">
          {stage === 'LISTENING' ? (
            <button
              onClick={handleStopListening}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-cyan-900/50 transition-all"
            >
              <Square className="w-4 h-4 fill-white" />
              <span>Finish Speaking & Reason</span>
            </button>
          ) : (
            <button
              onClick={handleInterrupt}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-all"
            >
              <Mic className="w-4 h-4" />
              <span>Interrupt / Talk Again</span>
            </button>
          )}

          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          <button
            onClick={handleConfirmAndReason}
            disabled={!transcript.trim()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-cyan-950/60 transition-all"
          >
            <span>Proceed to Action</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Safety Footer */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-5">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-500" />
          <span>No unapproved audio recording stored. Processed through safe AI pipeline.</span>
        </div>
      </div>
    </div>
  );
};
