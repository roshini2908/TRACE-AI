import React from 'react';
import {
  Building2,
  TrendingUp,
  AlertTriangle,
  Users,
  Leaf,
  ShieldCheck,
  Compass,
  BarChart3,
} from 'lucide-react';

export const CityIntelligenceView: React.FC = () => {
  const telemetryStats = [
    { label: 'Weekly Transit Friction Events', value: '142', change: '-8% vs last week', icon: TrendingUp, color: 'text-cyan-400' },
    { label: 'Ramp Obstructions Resolved', value: '89', change: '92% within 24h SLA', icon: ShieldCheck, color: 'text-emerald-400' },
    { label: 'Eco Depots Demand Peak', value: '1,280 kg', change: '+14% circular diversion', icon: Leaf, color: 'text-teal-400' },
    { label: 'Civic Service Queries Handled', value: '3,450', change: 'Top: Vital Records Checklist', icon: Users, color: 'text-violet-400' },
  ];

  const hotspotClusters = [
    {
      corridor: 'Market Street Corridor (Stop #1492 to #1540)',
      category: 'ACCESSIBILITY_BOTTLENECK',
      score: 'High Alert',
      pattern: 'Recurring commercial delivery unloading blocking designated wheelchair boarding pad between 8:15 AM – 9:30 AM.',
      resolution: 'Suggested municipal loading zone shift to Stevenson alley.',
    },
    {
      corridor: 'Dolores Park South Lawn & Playground',
      category: 'WASTE_OVERFLOW_SURGE',
      score: 'Weekend Spike',
      pattern: 'Public waste containers reach 120% capacity on sunny Saturdays between 3:00 PM – 6:00 PM.',
      resolution: 'Automated municipal recommendation: Deploy 4 auxiliary mobile compost/recycle bins during peak warm weekends.',
    },
    {
      corridor: 'Civic Center Metro Station Mezzanine',
      category: 'TRANSIT_WAYFINDING',
      score: 'Moderate',
      pattern: 'Elevator maintenance outages cause 12-minute detours for passengers with heavy luggage and mobility strollers.',
      resolution: 'Live prompt routing directs passengers directly to Van Ness accessible entrance prior to entering turnstiles.',
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-700/40 p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-indigo-950 border border-indigo-500/40 text-indigo-300 shadow-md">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">CivicPulse City Intelligence</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-700">
                  SMART CITY TELEMETRY
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Aggregated, privacy-safe urban friction insights helping city agencies build responsive public infrastructure.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Epistemic Grounding Disclaimer */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300">
        <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          <strong>Privacy-Preserving Telemetry:</strong> All citizen interactions are zero-knowledge stripped of personal identifiers and aggregated into spatial density clusters.
        </span>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {telemetryStats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">{stat.label}</span>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className="text-2xl font-black text-white font-mono">{stat.value}</div>
              <p className="text-[11px] text-slate-400">{stat.change}</p>
            </div>
          );
        })}
      </div>

      {/* Hotspot Clusters Card */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Anonymized Urban Friction Hotspots
            </h3>
          </div>
          <span className="text-[11px] text-slate-500">Live Spatial Cluster Map</span>
        </div>

        <div className="space-y-3">
          {hotspotClusters.map((cluster, i) => (
            <div
              key={i}
              className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                    {cluster.category}
                  </span>
                  <span className="font-bold text-white text-sm">{cluster.corridor}</span>
                </div>
                <span className="text-rose-400 font-semibold font-mono text-[11px]">
                  {cluster.score}
                </span>
              </div>

              <p className="text-slate-300 leading-relaxed">
                {cluster.pattern}
              </p>

              <div className="p-2.5 rounded-lg bg-slate-900 border border-indigo-950 text-indigo-200">
                <strong className="text-indigo-300">Algorithmic City Recommendation:</strong> {cluster.resolution}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
