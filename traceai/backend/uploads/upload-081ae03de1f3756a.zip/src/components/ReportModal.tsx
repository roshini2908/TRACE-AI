import React, { useState } from 'react';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  X,
  MapPin,
  Camera,
  Send,
  Save,
  ShieldCheck,
  Edit3,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CivicReportDraft, UserProfile } from '../types';
import { submitCivicReport } from '../services/civicApi';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  draftReport: CivicReportDraft;
  onReportSubmitted: (submittedReport: CivicReportDraft) => void;
  currentUser?: UserProfile | null;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  draftReport,
  onReportSubmitted,
  currentUser,
}) => {
  const [form, setForm] = useState<CivicReportDraft>({ ...draftReport });
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [humanApproved, setHumanApproved] = useState(false);
  const [submissionReceipt, setSubmissionReceipt] = useState<{
    trackingId: string;
    timestamp: string;
    disclaimer: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!humanApproved) return;

    setIsSubmitting(true);
    try {
      const response = await submitCivicReport({
        ...form,
        status: 'submitted',
      });

      setSubmissionReceipt({
        trackingId: response.trackingId,
        timestamp: response.timestamp,
        disclaimer: response.disclaimer,
      });

      // Confetti celebration for successful community action
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {}

      onReportSubmitted({
        ...form,
        id: response.trackingId,
        status: 'submitted',
      });
    } catch (err) {
      console.error('Report submission error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xl animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-amber-500/30 p-6 sm:p-8 shadow-2xl shadow-amber-950/50 text-slate-100 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          title="Close report modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-amber-950 border border-amber-700/50 text-amber-300">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-100">
                Civic Report Generator
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                DRAFT REVIEW
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Transforming citizen observations into structured, objective municipal service tickets.
            </p>
          </div>
        </div>

        {/* Human Control Guarantee Banner */}
        <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300 mb-5">
          <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong>Human Control Directives:</strong> AI drafts the objective facts. You review, edit, approve, or cancel. Never automatically dispatched without citizen authorization.
          </span>
        </div>

        {/* Submission Confirmation Screen */}
        {submissionReceipt ? (
          <div className="p-6 rounded-2xl bg-slate-950 border border-emerald-600/50 text-center space-y-4 animate-fade-in">
            <div className="w-12 h-12 rounded-full bg-emerald-950 border border-emerald-500 text-emerald-300 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-emerald-300">
                Civic Service Ticket Recorded
              </h3>
              <p className="text-xs font-mono text-cyan-400 mt-1">
                Tracking ID: <strong>{submissionReceipt.trackingId}</strong>
              </p>
            </div>

            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
              {submissionReceipt.disclaimer}
            </p>

            <div className="p-3 rounded-xl bg-slate-900 text-left text-xs text-slate-400 space-y-1">
              <p><strong className="text-slate-200">Dispatched To:</strong> Municipal Transit & Infrastructure Maintenance Desk</p>
              <p><strong className="text-slate-200">Incident Severity:</strong> {form.priority.toUpperCase()}</p>
              <p><strong className="text-slate-200">Location:</strong> {form.location}</p>
            </div>

            <div className="pt-2">
              <button
                onClick={onClose}
                className="px-6 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
              >
                Done & Return to Companion
              </button>
            </div>
          </div>
        ) : (
          /* Report Form */
          <div className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Report Title:
              </label>
              {isEditing ? (
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  className="w-full text-xs sm:text-sm bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                />
              ) : (
                <p className="text-sm font-bold text-slate-100 bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                  {form.title}
                </p>
              )}
            </div>

            {/* Category & Priority Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category:
                </label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value as any })}
                  className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200"
                >
                  <option value="BLOCKED_RAMP">BLOCKED_RAMP (Accessibility Barrier)</option>
                  <option value="POTHOLE">POTHOLE (Roadway/Pavement Hazard)</option>
                  <option value="WASTE">WASTE (Overflowing Litter)</option>
                  <option value="DAMAGED_INFRASTRUCTURE">DAMAGED_INFRASTRUCTURE</option>
                  <option value="SIGNAGE">SIGNAGE (Missing/Damaged Sign)</option>
                  <option value="TRAFFIC">TRAFFIC (Safety Friction)</option>
                  <option value="PUBLIC_SPACE">PUBLIC_SPACE (Park / Bench)</option>
                  <option value="ENVIRONMENT">ENVIRONMENT</option>
                  <option value="OTHER">OTHER</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Priority Dispatch Level:
                </label>
                <select
                  value={form.priority}
                  onChange={(e) => setForm({ ...form, priority: e.target.value as any })}
                  className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200"
                >
                  <option value="critical">Critical (Immediate safety risk)</option>
                  <option value="high">High (Major accessibility bottleneck)</option>
                  <option value="medium">Medium (Standard municipal maintenance)</option>
                  <option value="low">Low (General improvement)</option>
                </select>
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Factual Description (Objective & Neutral):
              </label>
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full text-xs sm:text-sm bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 resize-none leading-relaxed"
              />
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>Observed Location:</span>
              </label>
              <input
                type="text"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                className="w-full text-xs bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200"
              />
            </div>

            {/* Visible Evidence */}
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
              <span className="font-semibold text-cyan-300">Optical / Observational Evidence:</span>
              <p className="text-slate-300 font-mono text-[11px] leading-relaxed">
                {form.evidence}
              </p>
            </div>

            {/* Suggested Municipal Action */}
            <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 text-xs space-y-1">
              <span className="font-semibold text-amber-300">Suggested Remediation Action:</span>
              <p className="text-slate-200">{form.suggestedAction}</p>
            </div>

            {/* Human Approval Checkbox Gate */}
            <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/50 flex flex-col gap-2">
              <div className="flex items-start gap-2.5">
                <input
                  id="human-approval-toggle"
                  type="checkbox"
                  checked={humanApproved}
                  onChange={(e) => setHumanApproved(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700 focus:ring-cyan-500 cursor-pointer"
                />
                <label
                  htmlFor="human-approval-toggle"
                  className="text-xs text-slate-200 cursor-pointer leading-relaxed"
                >
                  <strong>I have verified this report:</strong> The information accurately reflects the visible civic situation and I authorize dispatch to the municipal service queue.
                </label>
              </div>
              {currentUser && (
                <div className="pl-6 text-[11px] text-cyan-300/90 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                  <span>Authorized by Citizen: <strong>{currentUser.name}</strong> ({currentUser.citizenBadgeId || currentUser.email})</span>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'Done Editing' : 'Edit Details'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-slate-400"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={!humanApproved || isSubmitting}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 disabled:opacity-40 text-white text-xs sm:text-sm font-bold shadow-lg shadow-amber-950/60 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? 'Submitting…' : 'Approve & Dispatch Report'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
