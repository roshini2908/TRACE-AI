import React, { useState } from 'react';
import {
  Zap,
  Play,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';

interface CivicPilotViewProps {
  onExecutePlan: (goal: string) => void;
}

export const CivicPilotView: React.FC<CivicPilotViewProps> = ({ onExecutePlan }) => {
  const [goalText, setGoalText] = useState(
    'Resolve inaccessible transit bottleneck at 4th & Market and find step-free route to public library.'
  );
  const [isRunning, setIsRunning] = useState(false);
  const [agentStep, setAgentStep] = useState<number>(0);
  const [approvedByHuman, setApprovedByHuman] = useState(false);

  const pilotTimeline = [
    {
      step: 1,
      title: 'Analyze Goal & Decompose Subtasks',
      status: 'completed',
      detail: 'Goal decomposed into: (1) Detect curb ramp barrier, (2) Route around obstacle via step-free corridors, (3) Draft municipal dispatch ticket.',
      tool: 'orchestrateClassifier',
    },
    {
      step: 2,
      title: 'Parallel Tool Invocations',
      status: 'completed',
      detail: 'Executed getLocationContext(), getAccessibleRoutes(radius=300m), and searchKnowledge("ADA Ramp Clearance Code §14-B").',
      tool: 'multiToolCaller',
    },
    {
      step: 3,
      title: 'Synthesize & Compare Outcomes',
      status: 'completed',
      detail: 'Compared 3 transit alternatives. Selected Mission & 4th Accessible Shuttle Stop as optimal (7 mins, 0 steps, 94% confidence).',
      tool: 'tradeoffComparator',
    },
    {
      step: 4,
      title: 'Safety & Epistemic Audit',
      status: 'completed',
      detail: 'Audited confidence thresholds. Flagged that municipal dispatch ticket requires explicit citizen signature.',
      tool: 'safetyGateAudit',
    },
    {
      step: 5,
      title: 'Wait for Citizen Approval Gate',
      status: 'waiting',
      detail: 'CivicPilot has paused consequential actions until user gives explicit authorization in UI.',
      tool: 'humanApprovalGate',
    },
    {
      step: 6,
      title: 'Dispatch & Actuation',
      status: 'pending',
      detail: 'Open step-free navigation overlay and send service ticket to municipal intake queue.',
      tool: 'civicActuator',
    },
  ];

  const handleStartAgent = () => {
    setIsRunning(true);
    setAgentStep(1);
    const interval = setInterval(() => {
      setAgentStep((prev) => {
        if (prev < 5) return prev + 1;
        clearInterval(interval);
        setIsRunning(false);
        return prev;
      });
    }, 1200);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-violet-950 via-slate-950 to-slate-900 border border-violet-700/50 p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-violet-900/60 text-violet-300 border border-violet-500/40">
              <Zap className="w-7 h-7 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">CivicPilot Agentic Mode</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-violet-950 text-violet-300 border border-violet-700">
                  SUPERVISED AGENT
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Autonomous task decomposition with mandatory Human-in-the-Loop approval before action.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleStartAgent}
              disabled={isRunning}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-40 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-violet-950/60 transition-all"
            >
              <Play className="w-4 h-4" />
              <span>{isRunning ? 'Agent Working…' : 'Run Supervised Agent'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Goal Formulation Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
        <label className="block text-xs font-semibold text-slate-300">
          Agent Directive / Public-Life Goal:
        </label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={goalText}
            onChange={(e) => setGoalText(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-violet-500"
          />
          <button
            onClick={handleStartAgent}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200"
          >
            Update Goal
          </button>
        </div>
      </div>

      {/* Agent Timeline */}
      <div className="p-5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-violet-300">
            CivicPilot Execution Timeline & Supervised Gates
          </h3>
          <span className="text-[11px] text-slate-500">
            Principle: AI plans and recommends; humans authorize.
          </span>
        </div>

        <div className="space-y-3">
          {pilotTimeline.map((item, idx) => {
            const isCompleted = agentStep > idx;
            const isCurrent = agentStep === idx + 1;

            return (
              <div
                key={item.step}
                className={`p-3.5 rounded-xl border transition-all ${
                  isCurrent
                    ? 'bg-violet-950/40 border-violet-500 shadow-md shadow-violet-950/40'
                    : isCompleted
                    ? 'bg-slate-900/90 border-slate-700'
                    : 'bg-slate-950 border-slate-800/60 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mt-0.5 ${
                        isCompleted
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500'
                          : isCurrent
                          ? 'bg-violet-600 text-white animate-pulse'
                          : 'bg-slate-900 text-slate-500 border border-slate-800'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : item.step}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs sm:text-sm font-bold text-slate-100">
                          {item.title}
                        </h4>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-slate-400 border border-slate-800">
                          {item.tool}()
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        {item.detail}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-semibold text-slate-500 shrink-0">
                    {isCompleted ? '✓ Done' : isCurrent ? 'Active…' : 'Pending'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Human Gate Authorization Card */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/30 to-violet-950/30 border border-amber-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-amber-300">
                CivicPilot Human Authorization Gate
              </h4>
              <p className="text-xs text-slate-300">
                Authorizing CivicPilot allows it to render the step-free navigation corridor and dispatch the service ticket draft.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setApprovedByHuman(true);
                setAgentStep(6);
                onExecutePlan(goalText);
              }}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md"
            >
              Approve & Actuate
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
