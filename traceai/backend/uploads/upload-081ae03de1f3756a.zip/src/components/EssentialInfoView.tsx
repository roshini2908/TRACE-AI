import React, { useState } from 'react';
import {
  FileCheck2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  Building,
  HelpCircle,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';

export const EssentialInfoView: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState('topic-1');

  const topics = [
    {
      id: 'topic-1',
      title: 'Municipal Vital Records (Birth / Marriage / Deed Certificates)',
      department: 'Office of the County Clerk & Recorder',
      address: '1 Dr Carlton B Goodlett Pl, Room 168',
      source: 'Municipal Code §24.12 — Updated Oct 2024',
      confidence: 96,
      verified: true,
      lastUpdated: 'Yesterday at 5:00 PM',
      whatYouNeed: [
        'Government-issued Photo ID (Driver License, Passport, or State ID card)',
        'Proof of relationship or legal entitlement (if requesting certified copy)',
        'Application form #VR-101 completed in black ink or submitted online prior',
        'Fee payment: $25.00 (Cashier check, debit/credit card; personal checks not accepted for walk-ins)',
      ],
      whatToPrepare: [
        'Exact full legal name of registrant at time of birth/event',
        'Exact date of event and hospital/borough where occurred',
        'Notarized sworn statement if ordering on behalf of an immediate relative',
      ],
      whatToCheckBeforeLeaving: [
        'Confirm public service counter closes at 4:00 PM (doors lock at 3:45 PM for queue cutoff)',
        'Ensure name on payment card matches presented photo ID',
        'Check that physical ID is not expired past 60 days',
      ],
      nextStep:
        'Walk through the Van Ness Avenue entrance for ADA step-free security screening, then take Elevator B directly to Room 168.',
    },
    {
      id: 'topic-2',
      title: 'Accessible Transit Discount Pass & Disability Placard',
      department: 'Regional Transit Access Department',
      address: 'Market Street Transit Customer Service Station',
      source: 'ADA Public Mobility Directory — Updated Nov 2024',
      confidence: 98,
      verified: true,
      lastUpdated: '3 days ago',
      whatYouNeed: [
        'Form RTC-500 completed and signed by a licensed healthcare professional',
        'State-issued identification or permanent resident card',
        'Existing transit smart-card (if migrating remaining balances)',
        'Zero fee for first-time disability verification issuance',
      ],
      whatToPrepare: [
        'Doctor’s medical license number and official clinic stamp',
        'Recent 2x2 passport-style color portrait photo (also taken free on-site)',
      ],
      whatToCheckBeforeLeaving: [
        'Medical certification must be dated within the last 90 calendar days',
        'Station has tactile braille pathways from street level',
      ],
      nextStep:
        'Visit Customer Counter 3 marked with the international accessibility symbol for priority processing.',
    },
    {
      id: 'topic-3',
      title: 'Household Hazardous Waste & Battery Drop-Off',
      department: 'Municipal Circular Cleanliness & Recycling Division',
      address: 'Tunnel Avenue Environmental Facility',
      source: 'Zero Waste Guidelines 2025',
      confidence: 94,
      verified: true,
      lastUpdated: '1 week ago',
      whatYouNeed: [
        'Proof of local residency (utility bill dated within 60 days or lease agreement)',
        'Items safely packed in original labeled containers or clear spill-proof tubs',
        'Maximum 15 gallons or 125 lbs total liquid waste per vehicle per visit',
      ],
      whatToPrepare: [
        'Separate lithium-ion batteries and tape terminals with clear packing tape',
        'Keep aerosol cans in a designated ventilated box',
      ],
      whatToCheckBeforeLeaving: [
        'Facility does not accept commercial biological waste on resident drop-off days',
        'Facility operates Tuesday–Saturday 8:00 AM – 4:00 PM (Closed Sundays)',
      ],
      nextStep:
        'Drive into Lane 1 for attendant unloading; stay inside vehicle while technicians remove containers.',
    },
  ];

  const currentTopic = topics.find((t) => t.id === selectedTopicId) || topics[0];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-950 to-slate-900 border border-emerald-700/40 p-6 shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 shadow-md">
            <FileCheck2 className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white">Essential Public Requirements & Checklists</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                GOVERNMENT KNOWLEDGE BASE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              "What do I need before visiting this public service?" Avoid wasted trips with verified preparation checklists.
            </p>
          </div>
        </div>
      </div>

      {/* Topic Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {topics.map((topic) => (
          <button
            key={topic.id}
            onClick={() => setSelectedTopicId(topic.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 text-left ${
              selectedTopicId === topic.id
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950/50'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {topic.title.split('(')[0]}
          </button>
        ))}
      </div>

      {/* Topic Card Display */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-5 shadow-xl">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white">
              {currentTopic.title}
            </h3>
            <p className="text-xs text-cyan-300 flex items-center gap-1.5 mt-0.5">
              <Building className="w-3.5 h-3.5" />
              <span>{currentTopic.department} — {currentTopic.address}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{currentTopic.confidence}% Verified</span>
            </span>
          </div>
        </div>

        {/* 4 Structured Information Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* What You Need */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>1. What You Need (Documents & Fees)</span>
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {currentTopic.whatYouNeed.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-cyan-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* What to Prepare */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <FileCheck2 className="w-4 h-4 text-amber-400" />
              <span>2. What to Prepare in Advance</span>
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {currentTopic.whatToPrepare.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* What to Check Before Leaving */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>3. What to Check Before Leaving</span>
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {currentTopic.whatToCheckBeforeLeaving.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-rose-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Next Step */}
          <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/40 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>4. Recommended Arrival Action</span>
            </h4>
            <p className="text-xs text-slate-200 leading-relaxed">
              {currentTopic.nextStep}
            </p>
          </div>
        </div>

        {/* Source Footnote */}
        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
          <span>Source: {currentTopic.source}</span>
          <span>Verified: {currentTopic.lastUpdated}</span>
        </div>
      </div>
    </div>
  );
};
