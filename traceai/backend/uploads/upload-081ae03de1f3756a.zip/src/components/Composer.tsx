import React, { useState } from 'react';
import {
  Mic,
  Camera,
  MapPin,
  Send,
  Sparkles,
  Navigation,
  Search,
  AlertTriangle,
  FileCheck,
  Leaf,
  Lightbulb,
  CornerDownLeft,
} from 'lucide-react';
import { LocationContext } from '../types';

interface ComposerProps {
  onSendMessage: (text: string, modality?: 'text' | 'voice') => void;
  onOpenVoice: () => void;
  onOpenPhoto: () => void;
  onUseLocation: () => void;
  currentLocation: LocationContext;
  isSubmitting?: boolean;
}

export const Composer: React.FC<ComposerProps> = ({
  onSendMessage,
  onOpenVoice,
  onOpenPhoto,
  onUseLocation,
  currentLocation,
  isSubmitting = false,
}) => {
  const [inputText, setInputText] = useState('');

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    if (!inputText.trim() || isSubmitting) return;
    onSendMessage(inputText.trim(), 'text');
    setInputText('');
  };

  const quickActions = [
    { label: 'Ask AI', query: 'What public services are available near me right now?', icon: Sparkles },
    { label: 'Plan a Journey', query: 'I need the easiest accessible step-free way to reach the library.', icon: Navigation },
    { label: 'Find a Service', query: 'Find an open community health center or public notary nearby.', icon: Search },
    { label: 'Analyze an Issue', query: 'The bus stop near me is overcrowded and the wheelchair ramp is blocked.', icon: AlertTriangle },
    { label: 'Get Information', query: 'What documents do I need before visiting municipal records?', icon: FileCheck },
    { label: 'Sustainability Help', query: 'How can I make this journey lower-carbon and locate recycling depots?', icon: Leaf },
    { label: 'Creative Solution', query: 'How can our neighborhood solve this street safety issue creatively?', icon: Lightbulb },
  ];

  return (
    <div className="w-full rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-cyan-900/40 p-4 sm:p-5 shadow-2xl shadow-cyan-950/30">
      {/* Title / Prompt */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
            <span>What’s happening around you?</span>
            <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          </h2>
          <p className="text-xs text-slate-400">
            Tell CivicPulse your real-world challenge via text, voice, photo, or current location.
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-950/60 px-2.5 py-1 rounded-lg border border-slate-800">
          <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span className="truncate max-w-[200px]">{currentLocation?.address || 'Current Location'}</span>
        </div>
      </div>

      {/* Primary Composer Textarea */}
      <div className="relative rounded-xl bg-slate-950/90 border border-slate-800 focus-within:border-cyan-500/80 focus-within:ring-2 focus-within:ring-cyan-500/20 transition-all p-3">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Describe what you need… (e.g. 'I am at a crowded bus stop and the accessible ramp is blocked')"
          rows={2}
          className="w-full bg-transparent text-sm sm:text-base text-slate-100 placeholder-slate-500 resize-none outline-none pr-12 leading-relaxed"
        />

        <div className="flex items-center justify-between pt-2 border-t border-slate-900/80 mt-1">
          {/* 4 Primary Input Buttons */}
          <div className="flex items-center flex-wrap gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={onOpenVoice}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-700/60 text-cyan-300 text-xs font-semibold hover:scale-[1.02] active:scale-[0.98] transition-all"
              title="Talk to CivicPulse Live"
            >
              <Mic className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>Talk to CivicPulse</span>
            </button>

            <button
              type="button"
              onClick={onOpenPhoto}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-950/70 hover:bg-blue-900/80 border border-blue-700/60 text-blue-300 text-xs font-semibold hover:scale-[1.02] active:scale-[0.98] transition-all"
              title="Upload / Capture Civic Photo"
            >
              <Camera className="w-3.5 h-3.5 text-blue-400" />
              <span>Analyze a Photo</span>
            </button>

            <button
              type="button"
              onClick={onUseLocation}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-medium transition-all"
              title="Detect or change current location"
            >
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              <span>Use My Location</span>
            </button>
          </div>

          {/* Send Action */}
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!inputText.trim() || isSubmitting}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 disabled:hover:from-cyan-500 disabled:hover:to-blue-600 text-white text-xs sm:text-sm font-semibold shadow-md shadow-cyan-950/60 transition-all"
          >
            <span>Reason & Act</span>
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Action Chips */}
      <div className="mt-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 shrink-0 mr-1">
            Quick Actions:
          </span>
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.label}
                onClick={() => onSendMessage(action.query, 'text')}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-800/80 text-slate-300 hover:text-cyan-300 text-xs shrink-0 transition-all duration-150"
              >
                <Icon className="w-3 h-3 text-cyan-400" />
                <span>{action.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
