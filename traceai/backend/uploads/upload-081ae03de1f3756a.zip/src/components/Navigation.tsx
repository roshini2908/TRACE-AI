import React from 'react';
import {
  LayoutDashboard,
  MessageSquareCode,
  Bus,
  Users,
  FileCheck2,
  Leaf,
  Lightbulb,
  FileText,
  Map as MapIcon,
  Clock,
  BrainCircuit,
  Building2,
  Zap,
  LogIn,
  ShieldCheck,
} from 'lucide-react';
import { UserProfile } from '../types';

export type NavSection =
  | 'home'
  | 'ask'
  | 'mobility'
  | 'civicpilot'
  | 'community'
  | 'information'
  | 'environment'
  | 'creative'
  | 'reports'
  | 'map'
  | 'activity'
  | 'memory'
  | 'city-intelligence';

interface NavigationProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  draftCount?: number;
  unreadActivities?: number;
  currentUser?: UserProfile | null;
  onOpenSignIn?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeSection,
  onSelectSection,
  draftCount = 0,
  currentUser,
  onOpenSignIn,
}) => {
  const mainItems: { id: NavSection; label: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
    { id: 'home', label: 'Home Center', icon: LayoutDashboard },
    { id: 'ask', label: 'Ask CivicPulse', icon: MessageSquareCode },
    { id: 'civicpilot', label: 'CivicPilot Agent', icon: Zap, badge: 'Agent' },
    { id: 'mobility', label: 'Mobility & Transit', icon: Bus },
    { id: 'community', label: 'Community Services', icon: Users },
    { id: 'information', label: 'Essential Info', icon: FileCheck2 },
    { id: 'environment', label: 'Environment & Green', icon: Leaf },
    { id: 'creative', label: 'Creative Solutions Lab', icon: Lightbulb },
    { id: 'reports', label: 'Civic Reports', icon: FileText, badge: draftCount > 0 ? `${draftCount}` : undefined },
    { id: 'map', label: 'Interactive Smart Map', icon: MapIcon },
    { id: 'activity', label: 'Activity & Saved', icon: Clock },
    { id: 'memory', label: 'Memory & Profile', icon: BrainCircuit },
    { id: 'city-intelligence', label: 'City Intelligence', icon: Building2 },
  ];

  return (
    <>
      {/* Desktop Sidebar Navigation */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-slate-800/80 bg-slate-950/60 p-4 space-y-6">
        <div>
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Public-Life Engine
          </p>
          <nav className="space-y-1">
            {mainItems.slice(0, 7).map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectSection(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-950/90 to-blue-950/70 text-cyan-300 border border-cyan-700/50 shadow-sm shadow-cyan-950/60'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div>
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
            Workspace & City
          </p>
          <nav className="space-y-1">
            {mainItems.slice(7).map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectSection(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-950/90 to-blue-950/70 text-cyan-300 border border-cyan-700/50 shadow-sm shadow-cyan-950/60'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Citizen Account / Sign In Widget */}
        <div className="mt-auto pt-3 border-t border-slate-900 space-y-3">
          {currentUser ? (
            <button
              onClick={onOpenSignIn}
              className="w-full text-left p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-cyan-800/80 transition-all flex items-center gap-2.5 group"
            >
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover border border-cyan-500/40 shrink-0"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-bold text-xs shrink-0">
                  {currentUser.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-bold text-slate-200 truncate group-hover:text-white">
                    {currentUser.name}
                  </p>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                </div>
                <p className="text-[10px] text-cyan-400/90 font-mono truncate">
                  {currentUser.citizenBadgeId || currentUser.role}
                </p>
              </div>
            </button>
          ) : (
            <button
              onClick={onOpenSignIn}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-950 to-blue-950 hover:from-cyan-900 hover:to-blue-900 border border-cyan-700/50 hover:border-cyan-500 text-cyan-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5 text-cyan-400" />
              <span>Sign In / Citizen ID</span>
            </button>
          )}

          {/* Philosophy Card */}
          <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-[11px] space-y-1.5">
            <p className="font-semibold text-cyan-300">Core Civic Principle</p>
            <p className="text-slate-400 leading-relaxed">
              AI recommends. Humans remain in control.
            </p>
            <div className="flex items-center gap-1 text-[10px] text-slate-500 pt-1">
              <span>See</span> → <span>Reason</span> → <span>Verify</span> → <span>Act</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800 px-3 py-2">
        <div className="flex items-center justify-around">
          {[
            { id: 'home', label: 'Home', icon: LayoutDashboard },
            { id: 'ask', label: 'Ask AI', icon: MessageSquareCode },
            { id: 'map', label: 'Map', icon: MapIcon },
            { id: 'reports', label: 'Reports', icon: FileText, badge: draftCount > 0 ? `${draftCount}` : undefined },
            { id: 'memory', label: 'Memory', icon: BrainCircuit },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSection(item.id as NavSection)}
                className={`relative flex flex-col items-center gap-1 px-3 py-1 rounded-lg text-[10px] font-medium transition-colors ${
                  isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="absolute top-0 right-2 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[9px] font-extrabold flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
