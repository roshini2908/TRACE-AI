import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  X,
  Eye,
  ShieldCheck,
  ArrowRight,
  FileText,
  RefreshCw,
} from 'lucide-react';
import { PhotoAnalysisResult } from '../types';
import { analyzePhoto } from '../services/civicApi';

interface PhotoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDraftReportFromPhoto: (analysis: PhotoAnalysisResult, imageBase64?: string) => void;
}

export const PhotoModal: React.FC<PhotoModalProps> = ({
  isOpen,
  onClose,
  onDraftReportFromPhoto,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [userComment, setUserComment] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<PhotoAnalysisResult | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Preset sample civic photos for instant testing without needing manual upload
  const presetPhotos = [
    {
      title: 'Blocked Transit Ramp (Pallet & Crowd)',
      category: 'BLOCKED_RAMP',
      comment: 'Commercial delivery pallet blocking designated wheelchair ramp at 4th & Market.',
      // SVG Data URL representation of a blocked bus curb ramp
      url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240"><rect width="400" height="240" fill="%231e293b"/><rect x="0" y="160" width="400" height="80" fill="%23334155"/><polygon points="80,160 160,200 40,200" fill="%23f59e0b"/><rect x="90" y="140" width="60" height="40" fill="%23b45309"/><text x="100" y="165" font-family="sans-serif" font-size="12" fill="%23fff">CARGO</text><circle cx="280" cy="120" r="14" fill="%2338bdf8"/><rect x="270" y="135" width="20" height="40" fill="%230284c7"/><text x="30" y="40" font-family="sans-serif" font-size="16" font-weight="bold" fill="%23f8fafc">Curb Cut Obstruction [Stop %231492]</text><text x="30" y="70" font-family="sans-serif" font-size="12" fill="%2394a3b8">Accessible boarding zone blocked by delivery pallet</text></svg>`,
    },
    {
      title: 'Park Waste Receptacle Overflow',
      category: 'WASTE',
      comment: 'Public waste bin overflowing onto the grass near playground.',
      url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240"><rect width="400" height="240" fill="%230f172a"/><rect x="0" y="150" width="400" height="90" fill="%23065f46"/><rect x="160" y="100" width="80" height="90" rx="6" fill="%23475569"/><text x="175" y="150" font-family="sans-serif" font-size="14" fill="%23cbd5e1">TRASH</text><circle cx="170" cy="85" r="12" fill="%23f43f5e"/><circle cx="210" cy="80" r="15" fill="%23eab308"/><circle cx="245" cy="95" r="10" fill="%2338bdf8"/><text x="30" y="40" font-family="sans-serif" font-size="16" font-weight="bold" fill="%23f8fafc">Dolores Park Litter Overflow</text><text x="30" y="70" font-family="sans-serif" font-size="12" fill="%23a7f3d0">Receptacle exceeding 120% volume capacity</text></svg>`,
    },
    {
      title: 'Deep Pedestrian Crosswalk Pothole',
      category: 'POTHOLE',
      comment: 'Asphalt crater in pedestrian and bike crosswalk path.',
      url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240"><rect width="400" height="240" fill="%231e293b"/><rect x="60" y="0" width="280" height="240" fill="%230f172a"/><line x1="80" y1="60" x2="80" y2="180" stroke="%23fff" stroke-width="10"/><line x1="130" y1="60" x2="130" y2="180" stroke="%23fff" stroke-width="10"/><ellipse cx="190" cy="120" rx="40" ry="25" fill="%23020617" stroke="%23dc2626" stroke-width="2"/><text x="30" y="30" font-family="sans-serif" font-size="16" font-weight="bold" fill="%23f8fafc">Asphalt Hazard Near Curb Cut</text></svg>`,
    },
  ];

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const b64 = reader.result as string;
      setSelectedImage(b64);
      setAnalysisResult(null);
      setAnalysisError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (preset: typeof presetPhotos[0]) => {
    setSelectedImage(preset.url);
    setUserComment(preset.comment);
    setAnalysisResult(null);
    setAnalysisError(null);
  };

  const handleRunAnalysis = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const result = await analyzePhoto({
        imageBase64: selectedImage,
        userComment: userComment || 'Analyze this civic photo for public life issues, accessibility barriers, or municipal hazards.',
      });
      setAnalysisResult(result);
    } catch (err: any) {
      setAnalysisError(err.message || 'Vision analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handlePrepareReport = () => {
    if (!analysisResult) return;
    onDraftReportFromPhoto(analysisResult, selectedImage || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xl animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-blue-500/30 p-6 sm:p-7 shadow-2xl shadow-blue-950/60 text-slate-100 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          title="Close photo modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-blue-950 border border-blue-700/50 text-blue-300">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">
              Civic Photo Intelligence
            </h2>
            <p className="text-xs text-slate-400">
              Multimodal Vision Reasoning for Urban Infrastructure & Accessibility Barriers
            </p>
          </div>
        </div>

        {/* Epistemic Honesty Banner */}
        <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300 mb-4">
          <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong>Epistemic Principle:</strong> Visible observations are classified as <em>Detected</em> or <em>Likely</em>. Never presented as unverified absolute fact until confirmed by authorities.
          </span>
        </div>

        {/* Preset Civic Scenarios */}
        <div className="space-y-1.5 mb-4">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Select a Sample Civic Photo or Upload Your Own:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {presetPhotos.map((preset, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleSelectPreset(preset)}
                className="text-left p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-cyan-700/80 transition-all text-xs space-y-1"
              >
                <p className="font-semibold text-cyan-300 line-clamp-1">{preset.title}</p>
                <p className="text-[10px] text-slate-400 line-clamp-2">{preset.comment}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Image Preview & Upload Area */}
        <div className="space-y-3 mb-5">
          {selectedImage ? (
            <div className="relative rounded-2xl overflow-hidden border border-slate-700/80 bg-slate-950 max-h-60 flex items-center justify-center">
              <img
                src={selectedImage}
                alt="Civic issue observation"
                className="w-full object-contain max-h-60"
              />
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-900/80 text-slate-300 hover:text-white"
                title="Remove photo"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-800 hover:border-cyan-600/80 rounded-2xl p-6 text-center cursor-pointer bg-slate-950/50 hover:bg-slate-950/80 transition-all space-y-2"
            >
              <Upload className="w-8 h-8 text-cyan-400 mx-auto animate-bounce" />
              <p className="text-sm font-semibold text-slate-200">
                Click to upload a civic photograph
              </p>
              <p className="text-xs text-slate-500">
                Supports JPG, PNG, WEBP (sidewalk barriers, potholes, transit ramps, overflowing bins)
              </p>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />

          {/* User Context Notes */}
          <input
            type="text"
            value={userComment}
            onChange={(e) => setUserComment(e.target.value)}
            placeholder="Add context notes (e.g. 'Near 4th St transit stop entrance facing south')…"
            className="w-full text-xs sm:text-sm bg-slate-950/90 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-500"
          />
        </div>

        {/* Analysis Action */}
        {!analysisResult && (
          <div className="flex justify-end gap-2 mb-4">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300"
            >
              Cancel
            </button>
            <button
              onClick={handleRunAnalysis}
              disabled={!selectedImage || isAnalyzing}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-cyan-950/50 transition-all"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing with Multimodal Gemini…</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Analyze Visible Civic Issue</span>
                </>
              )}
            </button>
          </div>
        )}

        {analysisError && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800 text-xs text-red-300 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{analysisError}</span>
          </div>
        )}

        {/* Analysis Result Card */}
        {analysisResult && (
          <div className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-800/60 space-y-3.5 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                  {analysisResult.detectedCategory}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-700">
                  Epistemic: {analysisResult.epistemicStatus}
                </span>
              </div>
              <div className="text-xs font-semibold text-cyan-400 flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                <span>Confidence: {analysisResult.confidence}%</span>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-100">
                {analysisResult.suggestedReportTitle}
              </h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                {analysisResult.suggestedDescription}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
              <span className="font-semibold text-cyan-300">Visible Evidence:</span>
              <p className="text-slate-300 font-mono text-[11px]">{analysisResult.visibleEvidence}</p>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Recommended Next Steps:
              </span>
              <ul className="mt-1 space-y-1">
                {analysisResult.suggestedNextActions.map((action, idx) => (
                  <li key={idx} className="flex items-center gap-1.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Launch Report Drafter */}
            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setAnalysisResult(null)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 text-xs text-slate-400 hover:text-slate-200"
              >
                Re-analyze
              </button>
              <button
                onClick={handlePrepareReport}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-semibold shadow-md shadow-cyan-950/60"
              >
                <FileText className="w-4 h-4" />
                <span>Draft Civic Report from Photo</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
