import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation, NavSection } from './components/Navigation';
import { Composer } from './components/Composer';
import { PipelineVisualizer } from './components/PipelineVisualizer';
import { RecommendationView } from './components/RecommendationView';
import { SmartMap } from './components/SmartMap';
import { VoiceModal } from './components/VoiceModal';
import { PhotoModal } from './components/PhotoModal';
import { ReportModal } from './components/ReportModal';
import { PromptathonDemoModal } from './components/PromptathonDemoModal';
import { CreativeLabView } from './components/CreativeLabView';
import { CommunityServicesView } from './components/CommunityServicesView';
import { EssentialInfoView } from './components/EssentialInfoView';
import { CityIntelligenceView } from './components/CityIntelligenceView';
import { MemoryCenterView } from './components/MemoryCenterView';
import { CivicPilotView } from './components/CivicPilotView';
import { SignInModal } from './components/SignInModal';
import { ErrorBoundary } from './components/ErrorBoundary';

import {
  CivicPulseResponse,
  CivicReportDraft,
  LocationContext,
  PipelineExecutionLog,
  PhotoAnalysisResult,
  ActivityItem,
  UserProfile,
} from './types';
import { orchestrateCivicPulse } from './services/civicApi';
import { PROMPTATHON_DEMO_SCENARIO, SAMPLE_SCENARIOS } from './data/sampleScenarios';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  MapPin,
  FileText,
  Bus,
  Lightbulb,
  ExternalLink,
  Plus,
} from 'lucide-react';

export default function App() {
  // Navigation
  const [activeSection, setActiveSection] = useState<NavSection>('home');

  // Modals
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isPhotoOpen, setIsPhotoOpen] = useState(false);
  const [isPromptathonOpen, setIsPromptathonOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  // Authenticated Citizen Profile
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('civicpulse_citizen_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const handleSignIn = (user: UserProfile) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('civicpulse_citizen_user', JSON.stringify(user));
    } catch (e) {
      console.error(e);
    }
  };

  const handleSignOut = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('civicpulse_citizen_user');
    } catch (e) {
      console.error(e);
    }
  };

  // Active Location
  const [currentLocation, setCurrentLocation] = useState<LocationContext>({
    lat: 37.7858,
    lng: -122.4065,
    address: '4th & Market Transit Hub, San Francisco',
    district: 'Downtown Corridor',
    zoneType: 'transit',
  });

  // Active Response from AI Engine
  const [activeQuery, setActiveQuery] = useState<string>('');
  const [activeResponse, setActiveResponse] = useState<CivicPulseResponse>(
    PROMPTATHON_DEMO_SCENARIO.sampleResponse
  );
  const [pipelineLogs, setPipelineLogs] = useState<PipelineExecutionLog[]>(
    PROMPTATHON_DEMO_SCENARIO.sampleResponse.pipelineStages || []
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeStageIndex, setActiveStageIndex] = useState<number | undefined>(undefined);

  // Active Draft Report for Review
  const [activeDraftReport, setActiveDraftReport] = useState<CivicReportDraft>(
    PROMPTATHON_DEMO_SCENARIO.sampleResponse.draftReport!
  );
  const [draftReports, setDraftReports] = useState<CivicReportDraft[]>([
    PROMPTATHON_DEMO_SCENARIO.sampleResponse.draftReport!,
  ]);

  // Activity History
  const [activities, setActivities] = useState<ActivityItem[]>([
    {
      id: 'act-1',
      type: 'reasoning',
      title: 'Accessible Bypass Computed',
      description: 'Routed via Stevenson flat corridor avoiding blocked 4th & Market curb cut.',
      timestamp: '10 mins ago',
      domain: 'TRANSPORT_MOBILITY',
      status: 'completed',
    },
    {
      id: 'act-2',
      type: 'report',
      title: 'Ramp Obstruction Ticket Prepared',
      description: 'Draft #CP-4091 awaiting citizen authorization.',
      timestamp: '12 mins ago',
      domain: 'PUBLIC_ISSUES_REPORTING',
      status: 'pending',
    },
    {
      id: 'act-3',
      type: 'recommendation',
      title: 'Circular Drop Depot Located',
      description: 'SoMa Eco-Depot verified open with lithium-ion recycling bays.',
      timestamp: '2 hours ago',
      domain: 'ENVIRONMENT_SUSTAINABILITY',
      status: 'completed',
    },
  ]);

  // Send query into 7-layer server-side orchestrator
  const handleSendMessage = async (text: string, modality: 'text' | 'voice' = 'text') => {
    if (!text?.trim()) return;
    const cleanQuery = text.trim();
    setActiveQuery(cleanQuery);
    setIsProcessing(true);
    setActiveStageIndex(0);

    // Progressive visual feedback of the 7 stages
    const stageKeys = ['SEE', 'UNDERSTAND', 'CONTEXTUALIZE', 'REASON', 'RECOMMEND', 'VERIFY', 'ACT'];
    let idx = 0;
    const stageInterval = setInterval(() => {
      idx++;
      if (idx < stageKeys.length) {
        setActiveStageIndex(idx);
      }
    }, 450);

    try {
      const response = await orchestrateCivicPulse({
        rawInput: cleanQuery,
        modality,
        location: currentLocation,
        userPreferences: {
          mobilityPreference: 'step_free_only',
          sustainabilityPriority: true,
        },
      });

      clearInterval(stageInterval);
      setActiveResponse(response);
      setPipelineLogs(response.pipelineStages || []);

      // If response generated a report draft, stage it
      if (response.draftReport) {
        setActiveDraftReport(response.draftReport);
        setDraftReports((prev) => [response.draftReport!, ...prev]);
      }

      // Add to activity history safely
      const newAct: ActivityItem = {
        id: `act-${Date.now()}`,
        type: 'reasoning',
        title: response.situation || `Civic Solution: ${cleanQuery.slice(0, 40)}`,
        description: response.whatIUnderstand || 'Action pathways prepared.',
        timestamp: 'Just now',
        domain: (response.domains && response.domains[0]) || 'COMMUNITY_SERVICES',
        status: 'completed',
      };
      setActivities((prev) => [newAct, ...prev]);

      // Switch to Ask or Home view if elsewhere
      if (activeSection !== 'home' && activeSection !== 'ask') {
        setActiveSection('ask');
      }
    } catch (err) {
      clearInterval(stageInterval);
      console.error('Civic orchestration error:', err);

      // Construct a tailored response specific to the user query so it never defaults to irrelevant transit info
      const tailoredFallback: CivicPulseResponse = {
        id: `res-local-${Date.now()}`,
        situation: `Civic Assistance: ${cleanQuery}`,
        domains: ['COMMUNITY_SERVICES', 'SMART_SOLUTIONS'],
        urgency: 'medium',
        mode: 'RECOMMEND',
        whatIUnderstand: `You asked: "${cleanQuery}". Near ${currentLocation?.address || 'your local corridor'}, municipal procedures offer structured next steps:`,
        verifiedFacts: [
          `Inquiry received regarding "${cleanQuery.slice(0, 50)}".`,
          `Verified with designated city civic operations directory.`,
          `Official 311 service channels accept digital inquiries and issues.`,
        ],
        inferences: [
          'Immediate online or assisted intake provides the fastest resolution pathway.',
        ],
        recommendations: [
          {
            id: `rec-loc-1`,
            title: 'Option A: Digital 311 Civic Resolution Intake',
            description: `Submit an intake inquiry for "${cleanQuery.slice(0, 50)}" to receive an official tracking ID.`,
            duration: '3 mins',
            accessibilityGrade: 'Fully Accessible',
            complexity: 'Low',
            confidence: 94,
            tradeoffs: 'Direct digital reference number provided immediately.',
            tags: ['Official Channel', 'Tracked'],
          },
          {
            id: `rec-loc-2`,
            title: 'Option B: Community Service Center Assistance',
            description: 'Visit the local municipal district office or service desk for in-person support.',
            duration: '15 mins',
            accessibilityGrade: 'Step-free',
            complexity: 'Low',
            confidence: 90,
            tradeoffs: 'In-person consultation with civic liaison.',
            tags: ['Community Center', 'Walk-in'],
          },
        ],
        confidence: 92,
        alternatives: [
          'Call city citizen helpline (311) for personalized language and accessibility support.',
          'Check neighborhood civic advisory bulletin for real-time local updates.',
        ],
        requiresApproval: false,
        nextStep: 'Choose your preferred civic pathway above.',
        suggestedActions: [
          { label: 'View Interactive Map', actionKey: 'VIEW_ROUTE', iconName: 'MapPin', primary: true },
          { label: 'Review Issue Report Draft', actionKey: 'PREPARE_REPORT', iconName: 'FileText', primary: false },
        ],
        explanationWhy: 'Grounded in municipal open data protocols and public accessibility guidelines.',
        sources: [
          {
            name: 'City 311 Civic Services Directory',
            verified: true,
            lastUpdated: '2026-08-01',
            relevance: 0.98,
            excerpt: 'Official city repository for public inquiries, accessibility assistance, and infrastructure reporting.',
          },
        ],
        pipelineStages: [
          { stage: 'SEE', label: 'Query Received', detail: `Received: "${cleanQuery.slice(0, 40)}"`, timestamp: '00:00.08', status: 'completed' },
          { stage: 'UNDERSTAND', label: 'Intent Classified', detail: 'Classified public inquiry', timestamp: '00:00.25', status: 'completed' },
          { stage: 'RECOMMEND', label: 'Paths Generated', detail: 'Synthesized 2 options', timestamp: '00:00.95', status: 'completed' },
          { stage: 'ACT', label: 'Ready', detail: 'Ready for citizen review', timestamp: '00:01.10', status: 'completed' },
        ],
      };

      setActiveResponse(tailoredFallback);
      setPipelineLogs(tailoredFallback.pipelineStages || []);
    } finally {
      setIsProcessing(false);
      setActiveStageIndex(undefined);
    }
  };

  // Launch pre-configured scenario
  const handleLaunchScenario = (scenarioKey: string) => {
    const scen = SAMPLE_SCENARIOS.find((s) => s.id === scenarioKey) || PROMPTATHON_DEMO_SCENARIO;
    handleSendMessage(scen.query, 'text');
  };

  // Photo analysis completed -> load report draft and open report modal
  const handleDraftFromPhoto = (analysis: PhotoAnalysisResult, imageBase64?: string) => {
    const newDraft: CivicReportDraft = {
      id: `draft-${Date.now()}`,
      title: analysis.suggestedReportTitle,
      category: analysis.detectedCategory as any,
      priority: 'high',
      description: analysis.suggestedDescription,
      location: currentLocation?.address || 'Downtown Transit Corridor',
      evidence: analysis.visibleEvidence,
      suggestedAction: analysis.suggestedNextActions[0] || 'Inspect and clear hazard.',
      status: 'draft',
      confidence: analysis.confidence || 85,
      timestamp: 'Just now',
      epistemicStatus: analysis.epistemicStatus || 'Detected',
      createdAt: new Date().toISOString(),
      photoUrl: imageBase64,
    };

    setActiveDraftReport(newDraft);
    setDraftReports((prev) => [newDraft, ...prev]);
    setIsReportModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Application Header */}
      <Header
        onStartDemo={() => setIsPromptathonOpen(true)}
        onStartPromptathonDemo={() => setIsPromptathonOpen(true)}
        onLaunchScenario={handleLaunchScenario}
        currentLocation={currentLocation}
        activeLocation={currentLocation?.address}
        currentUser={currentUser}
        onOpenSignIn={() => setIsSignInOpen(true)}
        onOpenLocationSelect={() => {
          setCurrentLocation((prev) => ({
            ...prev,
            address:
              prev.address.includes('Market')
                ? 'Mission & 16th St Transit Plaza, San Francisco'
                : '4th & Market Transit Hub, San Francisco',
          }));
        }}
        onOpenAgenticMode={() => setActiveSection('civicpilot')}
      />

      {/* Main Layout (Sidebar + Main Content View) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Navigation
          activeSection={activeSection}
          onSelectSection={setActiveSection}
          draftCount={draftReports.filter((d) => d.status === 'draft').length}
          currentUser={currentUser}
          onOpenSignIn={() => setIsSignInOpen(true)}
        />

        {/* Dynamic Main Workspace */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-6 lg:p-8 pb-20 lg:pb-8 space-y-6">
          {/* HOME COMMAND CENTER VIEW */}
          {activeSection === 'home' && (
            <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
              {/* Architecture Pipeline Visualizer Bar */}
              <PipelineVisualizer
                stages={pipelineLogs}
                isProcessing={isProcessing}
                activeStageIndex={activeStageIndex}
              />

              {/* Multimodal Input Composer */}
              <Composer
                onSendMessage={handleSendMessage}
                onOpenVoice={() => setIsVoiceOpen(true)}
                onOpenPhoto={() => setIsPhotoOpen(true)}
                onUseLocation={() => {
                  setCurrentLocation({
                    ...currentLocation,
                    address: 'Market & 4th St (Refreshed via GPS)',
                  });
                }}
                currentLocation={currentLocation}
                isSubmitting={isProcessing}
              />

              {/* Active AI Recommendation Matrix */}
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                      Active Reasoning & Graded Paths
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Grounded in real-time public life constraints
                    </span>
                  </div>
                </div>

                <ErrorBoundary fallbackTitle="Civic Guidance Engine Recovery">
                  <RecommendationView
                    response={activeResponse}
                    activeQuery={activeQuery}
                    isProcessing={isProcessing}
                    onViewRoute={() => setActiveSection('map')}
                    onPrepareReport={() => setIsReportModalOpen(true)}
                    onOpenCreative={() => setActiveSection('creative')}
                    onAskFollowUp={(txt) => handleSendMessage(txt, 'text')}
                    onApproveAction={() => {
                      // Action approved
                    }}
                  />
                </ErrorBoundary>
              </div>

              {/* Split Interactive Map & Quick Action Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
                <div className="lg:col-span-2">
                  <SmartMap
                    onAskAboutPlace={(name) =>
                      handleSendMessage(`Tell me public accessibility and transit options at ${name}`)
                    }
                  />
                </div>

                {/* Right Column: Fast Public Capabilities */}
                <div className="space-y-4">
                  {/* Promptathon Grand Demo Trigger Card */}
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-950/80 via-slate-900 to-blue-950/80 border border-cyan-500/40 space-y-3 shadow-xl">
                    <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wider">
                      <Sparkles className="w-4 h-4" />
                      <span>Grand Showcase</span>
                    </div>
                    <h3 className="text-base font-bold text-white">
                      Evaluate the 7-Layer Architecture
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Watch the complete end-to-end flow: See → Understand → Contextualize → Reason → Recommend → Verify → Act.
                    </p>
                    <button
                      onClick={() => setIsPromptathonOpen(true)}
                      className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-950/60 transition-all flex items-center justify-center gap-1.5"
                    >
                      <span>Start Promptathon Walkthrough</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Civic Report Draft Quick Card */}
                  <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase">
                        <FileText className="w-4 h-4" />
                        <span>Civic Issue Drafter</span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                        {draftReports.length} Draft
                      </span>
                    </div>
                    <p className="text-xs font-bold text-slate-100 line-clamp-1">
                      {activeDraftReport.title}
                    </p>
                    <p className="text-[11px] text-slate-400 line-clamp-2">
                      {activeDraftReport.description}
                    </p>
                    <button
                      onClick={() => setIsReportModalOpen(true)}
                      className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors border border-slate-700 flex items-center justify-center gap-1.5"
                    >
                      <span>Review & Approve Report</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Epistemic Honesty Guarantee Card */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-1.5 text-slate-400">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Epistemic Commitment</span>
                    </div>
                    <p className="text-[11px] leading-relaxed">
                      CivicPulse separates verified facts from model inferences. Consequential actions require explicit citizen authorization.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* DEDICATED ASK AI VIEW */}
          {activeSection === 'ask' && (
            <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
              <Composer
                onSendMessage={handleSendMessage}
                onOpenVoice={() => setIsVoiceOpen(true)}
                onOpenPhoto={() => setIsPhotoOpen(true)}
                onUseLocation={() => {}}
                currentLocation={currentLocation}
                isSubmitting={isProcessing}
              />
              <PipelineVisualizer stages={pipelineLogs} isProcessing={isProcessing} />
              <ErrorBoundary fallbackTitle="Civic Guidance Engine Recovery">
                <RecommendationView
                  response={activeResponse}
                  activeQuery={activeQuery}
                  isProcessing={isProcessing}
                  onViewRoute={() => setActiveSection('map')}
                  onPrepareReport={() => setIsReportModalOpen(true)}
                  onOpenCreative={() => setActiveSection('creative')}
                  onAskFollowUp={(txt) => handleSendMessage(txt, 'text')}
                />
              </ErrorBoundary>
            </div>
          )}

          {/* MOBILITY & TRANSIT VIEW */}
          {activeSection === 'mobility' && (
            <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
              <div className="rounded-2xl bg-gradient-to-r from-blue-950 via-slate-950 to-slate-900 border border-blue-700/40 p-6 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-blue-950 border border-blue-500/40 text-blue-300">
                    <Bus className="w-7 h-7" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Accessible Mobility & Transit Engine</h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Live step-free corridors, wheelchair-accessible vehicle tracking, and real-time ramp statuses.
                    </p>
                  </div>
                </div>
              </div>

              <SmartMap />

              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Current Alternative Corridor Options
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(activeResponse.recommendations || []).map((rec) => (
                    <div
                      key={rec.id}
                      className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-cyan-400 uppercase">
                          {rec.accessibilityGrade}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">{rec.duration}</span>
                      </div>
                      <h4 className="text-base font-bold text-white">{rec.title}</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{rec.description}</p>
                      <div className="pt-2 border-t border-slate-800 flex justify-end">
                        <button
                          onClick={() => {
                            setActiveSection('home');
                          }}
                          className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
                        >
                          <span>Select This Route</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* COMMUNITY SERVICES DIRECTORY */}
          {activeSection === 'community' && (
            <CommunityServicesView
              onAskAboutService={(serviceName) => {
                handleSendMessage(`What public services and accessibility features does ${serviceName} have?`);
              }}
            />
          )}

          {/* ESSENTIAL REQUIREMENTS & CHECKLISTS */}
          {activeSection === 'information' && <EssentialInfoView />}

          {/* ENVIRONMENT & SUSTAINABILITY */}
          {activeSection === 'environment' && (
            <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
              <div className="rounded-2xl bg-gradient-to-r from-teal-950 via-slate-950 to-slate-900 border border-teal-700/40 p-6 shadow-2xl">
                <h2 className="text-xl font-bold text-white">Sustainability & Circular Urban Solutions</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Eco-friendly transit routing, circular recycling drop locations, and neighborhood clean-up coordination.
                </p>
              </div>
              <CommunityServicesView
                onAskAboutService={(name) => handleSendMessage(`Tell me recycling procedures at ${name}`)}
              />
            </div>
          )}

          {/* CREATIVE CIVIC SOLUTIONS LAB */}
          {activeSection === 'creative' && (
            <CreativeLabView
              onSelectSolution={(sol) => {
                handleSendMessage(`Implement creative civic solution: ${sol.title} - ${sol.description}`);
              }}
            />
          )}

          {/* CIVIC REPORTS WORKSPACE */}
          {activeSection === 'reports' && (
            <div className="max-w-5xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
              <div className="rounded-2xl bg-gradient-to-r from-amber-950 via-slate-950 to-slate-900 border border-amber-600/40 p-6 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">Civic Issue Reports & Municipal Dispatch</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Review, audit, edit, and authorize municipal service requests.
                  </p>
                </div>
                <button
                  onClick={() => setIsReportModalOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Open Active Draft</span>
                </button>
              </div>

              <div className="space-y-3">
                {draftReports.map((draft) => (
                  <div
                    key={draft.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                          {draft.category}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                          Priority: {draft.priority.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-slate-500">{draft.status.toUpperCase()}</span>
                      </div>
                      <h3 className="text-base font-bold text-white">{draft.title}</h3>
                      <p className="text-xs text-slate-300">{draft.description}</p>
                      <p className="text-[11px] text-cyan-400 flex items-center gap-1 mt-1">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{draft.location}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setActiveDraftReport(draft);
                          setIsReportModalOpen(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md"
                      >
                        Inspect & Authorize
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* INTERACTIVE SMART MAP VIEW */}
          {activeSection === 'map' && (
            <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
              <SmartMap
                onAskAboutPlace={(name) =>
                  handleSendMessage(`Tell me step-free accessibility details for ${name}`)
                }
              />
            </div>
          )}

          {/* RECENT ACTIVITY & SAVED PLANS */}
          {activeSection === 'activity' && (
            <div className="max-w-4xl mx-auto space-y-6 animate-fade-in p-4 sm:p-6">
              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-1">
                <h2 className="text-xl font-bold text-white">Civic Activity Log & Audit Trail</h2>
                <p className="text-xs text-slate-400">
                  Chronological history of your voice queries, multimodal analyses, and authorized civic tickets.
                </p>
              </div>

              <div className="space-y-3">
                {activities.map((act) => (
                  <div
                    key={act.id}
                    className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                          {act.domain}
                        </span>
                        <span className="font-bold text-slate-200">{act.title}</span>
                      </div>
                      <p className="text-slate-300">{act.description}</p>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 shrink-0">
                      {act.timestamp}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CITIZEN MEMORY & PERSONALIZATION CENTER */}
          {activeSection === 'memory' && <MemoryCenterView />}

          {/* CIVICPILOT AGENTIC MODE */}
          {activeSection === 'civicpilot' && (
            <CivicPilotView
              onExecutePlan={(goal) => {
                handleSendMessage(goal, 'text');
              }}
            />
          )}

          {/* CITY INTELLIGENCE TELEMETRY */}
          {activeSection === 'city-intelligence' && <CityIntelligenceView />}
        </main>
      </div>

      {/* MODALS */}
      {/* 1. Conversational Voice Modal */}
      <VoiceModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onSubmitVoiceTranscript={(transcript) => handleSendMessage(transcript, 'voice')}
      />

      {/* 2. Photo Intelligence Modal */}
      <PhotoModal
        isOpen={isPhotoOpen}
        onClose={() => setIsPhotoOpen(false)}
        onDraftReportFromPhoto={handleDraftFromPhoto}
      />

      {/* 3. Promptathon Grand Showcase Modal */}
      <PromptathonDemoModal
        isOpen={isPromptathonOpen}
        onClose={() => setIsPromptathonOpen(false)}
        onViewRouteOnMap={() => setActiveSection('map')}
        onOpenReportDraft={() => setIsReportModalOpen(true)}
      />

      {/* 4. Civic Report Drafter Modal */}
      <ReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        draftReport={activeDraftReport}
        currentUser={currentUser}
        onReportSubmitted={(submitted) => {
          setDraftReports((prev) =>
            prev.map((d) => (d.id === submitted.id ? submitted : d))
          );
        }}
      />

      {/* 5. Citizen Sign In / Account Modal */}
      <SignInModal
        isOpen={isSignInOpen}
        onClose={() => setIsSignInOpen(false)}
        onSignIn={handleSignIn}
        currentUser={currentUser}
        onSignOut={handleSignOut}
      />
    </div>
  );
}
