import {
  CivicPulseResponse,
  PhotoAnalysisResult,
  CivicReportDraft,
  LocationContext,
  UserPreferences,
  CivicServiceItem,
  CityIntelligencePattern,
  KnowledgeSource,
} from '../types';

export async function orchestrateQuery(params: {
  userInput: string;
  modality: 'text' | 'voice' | 'photo' | 'location';
  location?: LocationContext;
  photoBase64?: string;
  preferences?: Partial<UserPreferences>;
  domainFilter?: string;
}): Promise<CivicPulseResponse> {
  const response = await fetch('/api/orchestrate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    throw new Error(`Orchestration error: ${response.statusText}`);
  }

  const result = await response.json();
  return result.data;
}

export async function orchestrateCivicPulse(params: {
  rawInput: string;
  modality?: 'text' | 'voice' | 'photo' | 'location';
  location?: LocationContext;
  photoBase64?: string;
  userPreferences?: Partial<UserPreferences>;
  domainFilter?: string;
}): Promise<CivicPulseResponse> {
  return orchestrateQuery({
    userInput: params.rawInput,
    modality: params.modality || 'text',
    location: params.location,
    photoBase64: params.photoBase64,
    preferences: params.userPreferences,
    domainFilter: params.domainFilter,
  });
}

export async function analyzePhoto(params: {
  imageBase64: string;
  mimeType?: string;
  userComment?: string;
}): Promise<PhotoAnalysisResult> {
  const response = await fetch('/api/analyze-photo', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    throw new Error(`Photo analysis failed: ${response.statusText}`);
  }

  const result = await response.json();
  return result.analysis;
}

export async function submitCivicReport(report: CivicReportDraft): Promise<{
  success: boolean;
  trackingId: string;
  timestamp: string;
  disclaimer: string;
  report: CivicReportDraft;
}> {
  const response = await fetch('/api/reports/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ report }),
  });

  if (!response.ok) {
    throw new Error(`Report submission failed: ${response.statusText}`);
  }

  return response.json();
}

export async function fetchKnowledge(): Promise<{
  sources: KnowledgeSource[];
  services: CivicServiceItem[];
}> {
  const response = await fetch('/api/knowledge');
  if (!response.ok) {
    throw new Error('Failed to fetch knowledge');
  }
  return response.json();
}

export async function fetchCityIntelligence(): Promise<{
  patterns: CityIntelligencePattern[];
  cityOverview: any;
}> {
  const response = await fetch('/api/city-intelligence');
  if (!response.ok) {
    throw new Error('Failed to fetch city intelligence');
  }
  return response.json();
}
